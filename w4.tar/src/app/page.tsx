'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Skeleton } from '@/components/ui/skeleton'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { LogViewer } from '@/components/log-viewer'
import { OllamaSettings } from '@/components/ollama-settings'
import { AIFixPreview } from '@/components/ai-fix-preview'
import { useWebSocket } from '@/hooks/use-websocket'
import { 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  XCircle, 
  TrendingUp, 
  TrendingDown,
  RefreshCw,
  Filter,
  Search,
  Settings,
  Server,
  Key,
  User,
  FileText,
  Wifi,
  WifiOff,
  Bell,
  BellOff,
  Bot,
  Brain,
  Zap
} from 'lucide-react'

interface Pipeline {
  id: string
  name: string
  status: 'running' | 'success' | 'failed' | 'pending'
  duration: number
  startTime: string
  buildNumber?: number
  buildUrl?: string
  failureStage?: string
  failureReason?: string
  developer: string
  branch: string
  stages: Stage[]
}

interface Stage {
  id: string
  name: string
  status: 'running' | 'success' | 'failed' | 'pending'
  duration: number
  logs: string[]
}

interface FailureStats {
  totalFailures: number
  commonFailures: Array<{
    reason: string
    count: number
    solution: string
  }>
  failureRate: number
  avgResolutionTime: number
}

export default function JenkinsDashboard() {
  const [pipelines, setPipelines] = useState<Pipeline[]>([])
  const [stats, setStats] = useState<FailureStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [jenkinsConfig, setJenkinsConfig] = useState({
    url: process.env.NEXT_PUBLIC_JENKINS_URL || '',
    username: process.env.NEXT_PUBLIC_JENKINS_USERNAME || '',
    apiToken: process.env.NEXT_PUBLIC_JENKINS_API_TOKEN || ''
  })
  const [configOpen, setConfigOpen] = useState(false)
  const [useMockData, setUseMockData] = useState(!process.env.NEXT_PUBLIC_JENKINS_URL) // Use mock data if no env vars set
  const [logViewerOpen, setLogViewerOpen] = useState(false)
  const [selectedPipeline, setSelectedPipeline] = useState<Pipeline | null>(null)
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>(
    process.env.NEXT_PUBLIC_JENKINS_URL ? 'connecting' : 'disconnected'
  )
  const [connectionError, setConnectionError] = useState('')
  const [isMounted, setIsMounted] = useState(false)
  const [ollamaConfigOpen, setOllamaConfigOpen] = useState(false)
  const [ollamaConfig, setOllamaConfig] = useState({
    baseUrl: process.env.NEXT_PUBLIC_OLLAMA_BASE_URL || 'http://localhost:11434',
    model: process.env.NEXT_PUBLIC_OLLAMA_MODEL || 'llama3.2',
    enabled: false,
    autoAnalyze: true
  })
  const [aiFixPreviewOpen, setAiFixPreviewOpen] = useState(false)
  const [currentAIAnalysis, setCurrentAIAnalysis] = useState<any>(null)
  const [currentPipelineForFix, setCurrentPipelineForFix] = useState<Pipeline | null>(null)
  
  // Debug: Log environment variables
  useEffect(() => {
    console.log('Environment variables:', {
      JENKINS_URL: process.env.NEXT_PUBLIC_JENKINS_URL,
      JENKINS_USERNAME: process.env.NEXT_PUBLIC_JENKINS_USERNAME,
      JENKINS_API_TOKEN: process.env.NEXT_PUBLIC_JENKINS_API_TOKEN ? '***' : undefined,
      useMockData: !process.env.NEXT_PUBLIC_JENKINS_URL
    })
  }, [])
  
  // WebSocket integration
  const pipelineIds = pipelines.map(p => p.id)
  const websocket = useWebSocket({
    autoConnect: true,
    enableNotifications: true,
    enableMonitoring: true,
    pipelineIds: pipelineIds
  })

  // Handle component mounting to avoid hydration issues
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Auto-connect to Jenkins on mount
  useEffect(() => {
    const autoConnect = async () => {
      if (jenkinsConfig.url && jenkinsConfig.username && jenkinsConfig.apiToken) {
        setConnectionStatus('connecting')
        setConnectionError('')

        try {
          // First test the connection
          const testResponse = await fetch('/api/jenkins/test-connection', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              url: jenkinsConfig.url,
              username: jenkinsConfig.username,
              apiToken: jenkinsConfig.apiToken
            })
          })

          const testResult = await testResponse.json()

          if (!testResult.success) {
            setConnectionStatus('error')
            setConnectionError(testResult.message || 'Failed to connect to Jenkins')
            setUseMockData(true) // Fallback to mock data
            return
          }

          // If connection test passes, try to fetch jobs
          const jobsResponse = await fetch(
            `/api/jenkins/jobs?url=${encodeURIComponent(jenkinsConfig.url)}&username=${encodeURIComponent(jenkinsConfig.username)}&apiToken=${encodeURIComponent(jenkinsConfig.apiToken)}`
          )

          if (jobsResponse.ok) {
            setConnectionStatus('connected')
            setUseMockData(false)
          } else {
            const errorData = await jobsResponse.json()
            setConnectionStatus('error')
            setConnectionError(errorData.error || 'Failed to fetch Jenkins jobs')
            setUseMockData(true) // Fallback to mock data
          }
        } catch (error) {
          console.error('Auto-connection error:', error)
          setConnectionStatus('error')
          setConnectionError('Network error while connecting to Jenkins. Please check if Jenkins is accessible from this browser.')
          setUseMockData(true) // Fallback to mock data
        }
      }
    }

    autoConnect()
  }, [jenkinsConfig])

  // Mock data for demonstration
  const mockPipelines: Pipeline[] = [
    {
      id: '1',
      name: 'frontend-build',
      status: 'failed',
      duration: 25,
      startTime: '2024-01-15T10:30:00Z',
      buildNumber: 42,
      buildUrl: 'http://20.121.40.237:8080/job/frontend-build/42/',
      failureStage: 'Unit Tests',
      failureReason: 'Test timeout after 10 minutes',
      developer: 'John Doe',
      branch: 'feature/new-ui',
      stages: [
        { id: '1-1', name: 'Checkout', status: 'success', duration: 2, logs: [] },
        { id: '1-2', name: 'Install Dependencies', status: 'success', duration: 5, logs: [] },
        { id: '1-3', name: 'Build', status: 'success', duration: 8, logs: [] },
        { id: '1-4', name: 'Unit Tests', status: 'failed', duration: 10, logs: ['Test timeout after 10 minutes'] },
      ]
    },
    {
      id: '2',
      name: 'backend-deploy',
      status: 'running',
      duration: 15,
      startTime: '2024-01-15T10:45:00Z',
      buildNumber: 38,
      buildUrl: 'http://20.121.40.237:8080/job/backend-deploy/38/',
      developer: 'Jane Smith',
      branch: 'main',
      stages: [
        { id: '2-1', name: 'Checkout', status: 'success', duration: 2, logs: [] },
        { id: '2-2', name: 'Build Docker Image', status: 'success', duration: 6, logs: [] },
        { id: '2-3', name: 'Deploy to Staging', status: 'running', duration: 7, logs: [] },
      ]
    },
    {
      id: '3',
      name: 'e2e-tests',
      status: 'success',
      duration: 45,
      startTime: '2024-01-15T09:00:00Z',
      buildNumber: 67,
      buildUrl: 'http://20.121.40.237:8080/job/e2e-tests/67/',
      developer: 'Mike Johnson',
      branch: 'develop',
      stages: [
        { id: '3-1', name: 'Setup Environment', status: 'success', duration: 5, logs: [] },
        { id: '3-2', name: 'Run Tests', status: 'success', duration: 35, logs: [] },
        { id: '3-3', name: 'Generate Report', status: 'success', duration: 5, logs: [] },
      ]
    }
  ]

  const mockStats: FailureStats = {
    totalFailures: 12,
    commonFailures: [
      {
        reason: 'Test timeout',
        count: 5,
        solution: 'Increase test timeout or optimize test performance'
      },
      {
        reason: 'Memory limit exceeded',
        count: 3,
        solution: 'Increase memory allocation or optimize memory usage'
      },
      {
        reason: 'Network connectivity issues',
        count: 2,
        solution: 'Check network configuration and retry logic'
      },
      {
        reason: 'Dependency conflicts',
        count: 2,
        solution: 'Update dependencies or resolve version conflicts'
      }
    ],
    failureRate: 24,
    avgResolutionTime: 45
  }

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      
      try {
        if (useMockData || !jenkinsConfig.url) {
          // Use mock data for demo
          await new Promise(resolve => setTimeout(resolve, 1000))
          setPipelines(mockPipelines)
          setStats(mockStats)
        } else {
          // Fetch real data from Jenkins
          const jobsResponse = await fetch(
            `/api/jenkins/jobs?url=${encodeURIComponent(jenkinsConfig.url)}&username=${encodeURIComponent(jenkinsConfig.username)}&apiToken=${encodeURIComponent(jenkinsConfig.apiToken)}`
          )
          
          if (!jobsResponse.ok) {
            throw new Error('Failed to fetch Jenkins jobs')
          }
          
          const jobs = await jobsResponse.json()
          setPipelines(jobs)
          
          // Calculate stats from real data
          const failedJobs = jobs.filter((job: Pipeline) => job.status === 'failed')
          const failureRate = jobs.length > 0 ? (failedJobs.length / jobs.length) * 100 : 0
          
          setStats({
            totalFailures: failedJobs.length,
            commonFailures: [
              {
                reason: 'Test timeout',
                count: Math.floor(failedJobs.length * 0.4),
                solution: 'Increase test timeout or optimize test performance'
              },
              {
                reason: 'Memory limit exceeded',
                count: Math.floor(failedJobs.length * 0.3),
                solution: 'Increase memory allocation or optimize memory usage'
              },
              {
                reason: 'Network connectivity issues',
                count: Math.floor(failedJobs.length * 0.2),
                solution: 'Check network configuration and retry logic'
              },
              {
                reason: 'Dependency conflicts',
                count: Math.floor(failedJobs.length * 0.1),
                solution: 'Update dependencies or resolve version conflicts'
              }
            ],
            failureRate: Math.round(failureRate),
            avgResolutionTime: 45
          })
        }
      } catch (error) {
        console.error('Error fetching data:', error)
        // Fallback to mock data
        setPipelines(mockPipelines)
        setStats(mockStats)
      } finally {
        setLoading(false)
      }
    }

    fetchData()

    if (autoRefresh) {
      const interval = setInterval(fetchData, 30000) // Refresh every 30 seconds
      return () => clearInterval(interval)
    }
  }, [autoRefresh, jenkinsConfig, useMockData])

  // Handle real-time WebSocket updates
  useEffect(() => {
    if (websocket.pipelineUpdates.length > 0) {
      // Update pipelines with real-time data
      const latestUpdate = websocket.pipelineUpdates[websocket.pipelineUpdates.length - 1]
      setPipelines(prev => prev.map(p => 
        p.id === latestUpdate.id 
          ? { ...p, status: latestUpdate.status, stage: latestUpdate.stage }
          : p
      ))
    }
  }, [websocket.pipelineUpdates])

  // Update WebSocket pipeline subscriptions when pipelines change
  useEffect(() => {
    const pipelineIds = pipelines.map(p => p.id)
    // The WebSocket hook will handle the subscription updates automatically
  }, [pipelines])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />
      case 'running':
        return <Clock className="h-4 w-4 text-blue-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-100 text-green-800'
      case 'failed':
        return 'bg-red-100 text-red-800'
      case 'running':
        return 'bg-blue-100 text-blue-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const handleQuickFix = async (pipelineId: string) => {
    const pipeline = pipelines.find(p => p.id === pipelineId)
    if (!pipeline) return

    try {
      // Show loading state
      const originalStatus = pipeline.status
      setPipelines(prev => prev.map(p => 
        p.id === pipelineId ? { ...p, status: 'running' as const } : p
      ))

      if (useMockData) {
        // Simulate quick fix for mock data with AI analysis
        if (ollamaConfig.enabled) {
          // Create mock AI analysis for demonstration
          const mockAIAnalysis = {
            rootCause: 'Test timeout due to inefficient test cases and insufficient timeout configuration',
            confidence: '85%',
            immediateActions: [
              'Increase test timeout from 10 minutes to 15 minutes',
              'Optimize test cases to reduce execution time',
              'Add parallel test execution',
              'Update test configuration file'
            ],
            fileChanges: [
              {
                filePath: 'jest.config.js',
                changeType: 'modify' as const,
                description: 'Increase test timeout and add parallel execution configuration',
                content: `module.exports = {
  testTimeout: 900000, // 15 minutes
  maxWorkers: 4,
  verbose: true,
  // ... other config
}`
              },
              {
                filePath: 'package.json',
                changeType: 'modify' as const,
                description: 'Update test script to include parallel execution flag',
                content: `"test": "jest --runInBand --coverage"`
              }
            ],
            pipelineChanges: [
              {
                parameter: 'TEST_TIMEOUT',
                oldValue: '600',
                newValue: '900',
                description: 'Increase test timeout parameter'
              },
              {
                parameter: 'PARALLEL_TESTS',
                oldValue: 'false',
                newValue: 'true',
                description: 'Enable parallel test execution'
              }
            ],
            riskAssessment: {
              level: 'low' as const,
              description: 'Low risk changes that only affect test configuration and execution parameters',
              mitigations: [
                'Changes are backwards compatible',
                'No impact on production code',
                'Can be easily rolled back if issues occur'
              ]
            }
          }
          
          setCurrentPipelineForFix(pipeline)
          setCurrentAIAnalysis(mockAIAnalysis)
          setAiFixPreviewOpen(true)
        } else {
          await new Promise(resolve => setTimeout(resolve, 2000))
          alert(`Quick fix applied to ${pipeline.name}: Issue resolved successfully!`)
          setPipelines(prev => prev.map(p => 
            p.id === pipelineId ? { ...p, status: 'success' as const, failureReason: undefined, failureStage: undefined } : p
          ))
        }
      } else {
        // AI-powered failure analysis if Ollama is enabled
        if (ollamaConfig.enabled && ollamaConfig.autoAnalyze && pipeline.failureReason) {
          try {
            // Get logs for AI analysis
            const logsResponse = await fetch(`/api/jenkins/logs`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                jobName: pipeline.name,
                buildNumber: pipeline.buildNumber,
                jenkinsUrl: jenkinsConfig.url,
                username: jenkinsConfig.username,
                apiToken: jenkinsConfig.apiToken
              })
            })

            const logsData = await logsResponse.json()
            const logs = logsData.stages?.flatMap((stage: any) => stage.logs) || []

            // Perform AI analysis with enhanced action to get detailed changes
            const aiResponse = await fetch('/api/ollama', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                action: 'generate-detailed-fix',
                failureReason: pipeline.failureReason,
                logs: logs,
                jobName: pipeline.name,
                buildNumber: pipeline.buildNumber,
                config: ollamaConfig
              })
            })

            const aiResult = await aiResponse.json()
            
            if (aiResult.success) {
              const analysis = aiResult.analysis
              setCurrentPipelineForFix(pipeline)
              setCurrentAIAnalysis(analysis)
              setAiFixPreviewOpen(true)
            } else {
              throw new Error('AI analysis failed')
            }
          } catch (aiError) {
            console.error('AI analysis failed:', aiError)
            // Fallback to regular quick fix
            const response = await fetch(`/api/jenkins/build`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                jobName: pipeline.name,
                jenkinsUrl: jenkinsConfig.url,
                username: jenkinsConfig.username,
                apiToken: jenkinsConfig.apiToken,
                parameters: {
                  QUICK_FIX: 'true',
                  RESOLVE_ISSUE: 'automatic'
                }
              })
            })

            if (response.ok) {
              alert(`Quick fix triggered for ${pipeline.name}: AI analysis failed, applied standard fix`)
            } else {
              throw new Error('Failed to trigger quick fix')
            }
          }
        } else {
          // Regular quick fix without AI
          const response = await fetch(`/api/jenkins/build`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              jobName: pipeline.name,
              jenkinsUrl: jenkinsConfig.url,
              username: jenkinsConfig.username,
              apiToken: jenkinsConfig.apiToken,
              parameters: {
                QUICK_FIX: 'true',
                RESOLVE_ISSUE: 'automatic'
              }
            })
          })

          if (response.ok) {
            alert(`Quick fix triggered for ${pipeline.name}: Build restarted with fix parameters!`)
          } else {
            throw new Error('Failed to trigger quick fix')
          }
        }
      }
    } catch (error) {
      console.error('Quick fix failed:', error)
      // Revert status on failure
      setPipelines(prev => prev.map(p => 
        p.id === pipelineId ? { ...p, status: pipeline.status } : p
      ))
      alert(`Quick fix failed for ${pipeline.name}: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  const handleConfirmAIFix = async () => {
    if (!currentPipelineForFix || !currentAIAnalysis) return

    try {
      // Trigger build with AI-recommended parameters
      const response = await fetch(`/api/jenkins/build`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jobName: currentPipelineForFix.name,
          jenkinsUrl: jenkinsConfig.url,
          username: jenkinsConfig.username,
          apiToken: jenkinsConfig.apiToken,
          parameters: {
            QUICK_FIX: 'true',
            RESOLVE_ISSUE: 'automatic',
            AI_ANALYSIS: 'true',
            ROOT_CAUSE: currentAIAnalysis.rootCause,
            CONFIDENCE: currentAIAnalysis.confidence,
            // Add file changes as parameters
            FILE_CHANGES: JSON.stringify(currentAIAnalysis.fileChanges || []),
            PIPELINE_CHANGES: JSON.stringify(currentAIAnalysis.pipelineChanges || [])
          }
        })
      })

      if (response.ok) {
        alert(`AI-powered fix triggered for ${currentPipelineForFix.name}: Applied detailed changes with ${currentAIAnalysis.confidence} confidence`)
      } else {
        throw new Error('Failed to trigger AI-powered fix')
      }
    } catch (error) {
      console.error('AI fix application failed:', error)
      alert(`Failed to apply AI fix: ${error instanceof Error ? error.message : 'Unknown error'}`)
      // Revert status on failure
      setPipelines(prev => prev.map(p => 
        p.id === currentPipelineForFix!.id ? { ...p, status: currentPipelineForFix!.status } : p
      ))
    }
  }

  const handleRejectAIFix = () => {
    if (currentPipelineForFix) {
      // Revert status on rejection
      setPipelines(prev => prev.map(p => 
        p.id === currentPipelineForFix!.id ? { ...p, status: currentPipelineForFix!.status } : p
      ))
    }
    setAiFixPreviewOpen(false)
    setCurrentAIAnalysis(null)
    setCurrentPipelineForFix(null)
  }

  const handleSaveConfig = async () => {
    if (!jenkinsConfig.url || !jenkinsConfig.username || !jenkinsConfig.apiToken) {
      setConnectionError('Please fill in all required fields')
      return
    }

    setConnectionStatus('connecting')
    setConnectionError('')

    try {
      // First test the connection
      const testResponse = await fetch('/api/jenkins/test-connection', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url: jenkinsConfig.url,
          username: jenkinsConfig.username,
          apiToken: jenkinsConfig.apiToken
        })
      })

      const testResult = await testResponse.json()

      if (!testResult.success) {
        setConnectionStatus('error')
        setConnectionError(testResult.message || 'Failed to connect to Jenkins')
        return
      }

      // If connection test passes, try to fetch jobs
      const jobsResponse = await fetch(
        `/api/jenkins/jobs?url=${encodeURIComponent(jenkinsConfig.url)}&username=${encodeURIComponent(jenkinsConfig.username)}&apiToken=${encodeURIComponent(jenkinsConfig.apiToken)}`
      )

      if (jobsResponse.ok) {
        setConnectionStatus('connected')
        setUseMockData(false)
        setConfigOpen(false)
        // Trigger a refresh with new config
        setLoading(true)
      } else {
        const errorData = await jobsResponse.json()
        setConnectionStatus('error')
        setConnectionError(errorData.error || 'Failed to fetch Jenkins jobs')
      }
    } catch (error) {
      console.error('Connection error:', error)
      setConnectionStatus('error')
      setConnectionError('Network error while connecting to Jenkins. Please check if Jenkins is accessible from this browser.')
    }
  }

  const handleViewLogs = async (pipelineId: string) => {
    const pipeline = pipelines.find(p => p.id === pipelineId)
    if (!pipeline) return

    try {
      if (useMockData) {
        // For mock data, use the existing mock logs
        setSelectedPipeline(pipeline)
        setLogViewerOpen(true)
      } else {
        // For real data, fetch the latest build logs
        console.log('Fetching logs for pipeline:', pipeline.name, 'Build number:', pipeline.buildNumber)
        
        const response = await fetch(`/api/jenkins/logs`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            jobName: pipeline.name,
            buildNumber: pipeline.buildNumber,
            jenkinsUrl: jenkinsConfig.url,
            username: jenkinsConfig.username,
            apiToken: jenkinsConfig.apiToken
          })
        })

        console.log('Logs response status:', response.status)
        
        if (response.ok) {
          const logData = await response.json()
          console.log('Log data received:', logData)
          // Update pipeline with real logs
          const updatedPipeline = {
            ...pipeline,
            stages: logData.stages || []
          }
          setSelectedPipeline(updatedPipeline)
          setLogViewerOpen(true)
        } else {
          const errorText = await response.text()
          console.error('Failed to fetch logs:', response.status, errorText)
          throw new Error(`Failed to fetch logs: ${response.status} ${errorText}`)
        }
      }
    } catch (error) {
      console.error('Error fetching logs:', error)
      alert(`Failed to fetch logs for ${pipeline.name}: ${error instanceof Error ? error.message : 'Unknown error'}`)
      // Fallback to showing the pipeline without logs
      setSelectedPipeline(pipeline)
      setLogViewerOpen(true)
    }
  }

  const handleDebugLogs = async (pipelineId: string) => {
    const pipeline = pipelines.find(p => p.id === pipelineId)
    if (!pipeline) return

    try {
      const debugUrl = `/api/debug/logs?jobName=${encodeURIComponent(pipeline.name)}&buildNumber=${pipeline.buildNumber || ''}&url=${encodeURIComponent(jenkinsConfig.url)}&username=${encodeURIComponent(jenkinsConfig.username)}&apiToken=${encodeURIComponent(jenkinsConfig.apiToken)}`
      
      console.log('Debug URL:', debugUrl)
      
      const response = await fetch(debugUrl)
      const debugData = await response.json()
      
      console.log('Debug data:', debugData)
      
      // Open debug data in new window
      const debugWindow = window.open('', '_blank')
      if (debugWindow) {
        debugWindow.document.write(`
          <html>
            <head><title>Debug Logs - ${pipeline.name}</title></head>
            <body>
              <h1>Debug Logs for ${pipeline.name}</h1>
              <pre>${JSON.stringify(debugData, null, 2)}</pre>
            </body>
          </html>
        `)
      }
    } catch (error) {
      console.error('Debug failed:', error)
      alert(`Debug failed: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  const handleDownloadLogs = async (pipelineId: string) => {
    const pipeline = pipelines.find(p => p.id === pipelineId)
    if (!pipeline) return

    try {
      const downloadUrl = `/api/download/logs?jobName=${encodeURIComponent(pipeline.name)}&buildNumber=${pipeline.buildNumber || ''}&url=${encodeURIComponent(jenkinsConfig.url)}&username=${encodeURIComponent(jenkinsConfig.username)}&apiToken=${encodeURIComponent(jenkinsConfig.apiToken)}`
      
      console.log('Download URL:', downloadUrl)
      
      // Create a temporary link to download the file
      const link = document.createElement('a')
      link.href = downloadUrl
      link.download = `${pipeline.name}-${pipeline.buildNumber || 'latest'}-logs.txt`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (error) {
      console.error('Download failed:', error)
      alert(`Download failed: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  const handleRestartPipeline = async (pipelineId: string) => {
    console.log('Restart pipeline called:', pipelineId)
    const pipeline = pipelines.find(p => p.id === pipelineId)
    if (!pipeline) return

    try {
      console.log('Restarting pipeline:', pipeline.name)
      // Show loading state
      const originalStatus = pipeline.status
      setPipelines(prev => prev.map(p => 
        p.id === pipelineId ? { ...p, status: 'running' as const } : p
      ))

      if (useMockData) {
        console.log('Using mock data for restart')
        // Simulate restart for mock data
        await new Promise(resolve => setTimeout(resolve, 2000))
        setPipelines(prev => prev.map(p => 
          p.id === pipelineId ? { ...p, status: 'success' as const, failureReason: undefined, failureStage: undefined } : p
        ))
        alert(`Restarted ${pipeline.name}: Build completed successfully!`)
      } else {
        console.log('Using real Jenkins for restart')
        // Real implementation - trigger new build
        const requestBody = {
          jobName: pipeline.name,
          jenkinsUrl: jenkinsConfig.url,
          username: jenkinsConfig.username,
          apiToken: jenkinsConfig.apiToken,
          parameters: {
            RESTART_BUILD: 'true',
            TRIGGERED_BY: 'pipeline_monitor'
          }
        }
        console.log('Sending build request:', requestBody)
        
        const response = await fetch(`/api/jenkins/build`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody)
        })

        console.log('Build response status:', response.status)
        
        if (response.ok) {
          const result = await response.json()
          console.log('Build response:', result)
          alert(`Restarted ${pipeline.name}: ${result.message}`)
        } else {
          const errorText = await response.text()
          console.log('Build error response:', errorText)
          throw new Error(`Failed to restart pipeline: ${response.status} ${errorText}`)
        }
      }
    } catch (error) {
      console.error('Restart failed:', error)
      // Revert status on failure
      setPipelines(prev => prev.map(p => 
        p.id === pipelineId ? { ...p, status: pipeline.status } : p
      ))
      alert(`Restart failed for ${pipeline.name}: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  const handleStopPipeline = async (pipelineId: string) => {
    const pipeline = pipelines.find(p => p.id === pipelineId)
    if (!pipeline || pipeline.status !== 'running') return

    try {
      if (useMockData) {
        // Simulate stop for mock data
        setPipelines(prev => prev.map(p => 
          p.id === pipelineId ? { ...p, status: 'failed' as const } : p
        ))
        alert(`Stopped ${pipeline.name}: Build aborted by user`)
      } else {
        // Real implementation - stop the build
        const response = await fetch(`/api/jenkins/stop`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            jobName: pipeline.name,
            buildNumber: pipeline.buildNumber || 1, // Use actual build number if available
            jenkinsUrl: jenkinsConfig.url,
            username: jenkinsConfig.username,
            apiToken: jenkinsConfig.apiToken
          })
        })

        if (response.ok) {
          const result = await response.json()
          setPipelines(prev => prev.map(p => 
            p.id === pipelineId ? { ...p, status: 'failed' as const } : p
          ))
          alert(`Stopped ${pipeline.name}: ${result.message}`)
        } else {
          throw new Error('Failed to stop pipeline')
        }
      }
    } catch (error) {
      console.error('Stop failed:', error)
      alert(`Stop failed for ${pipeline.name}: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  const getConnectionIcon = () => {
    switch (connectionStatus) {
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'connecting':
        return <Clock className="h-4 w-4 text-blue-500 animate-spin" />
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  const getConnectionColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'bg-green-100 text-green-800'
      case 'connecting':
        return 'bg-blue-100 text-blue-800'
      case 'error':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Jenkins Pipeline Monitor</h1>
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Configuration Notice */}
      {useMockData && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-800">
              <AlertCircle className="h-5 w-5" />
              Configuration Required
            </CardTitle>
            <CardDescription className="text-yellow-700">
              Connect to your Jenkins server to monitor real pipelines. Currently running in demo mode with mock data.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isMounted && (
              <Dialog open={configOpen} onOpenChange={setConfigOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-yellow-600 hover:bg-yellow-700">
                    <Server className="mr-2 h-4 w-4" />
                    Configure Jenkins Connection
                  </Button>
                </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Jenkins Configuration</DialogTitle>
                  <DialogDescription>
                    Enter your Jenkins server details to connect and monitor real pipelines.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="url" className="text-right">
                      Jenkins URL <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="url"
                      placeholder="https://jenkins.example.com"
                      className="col-span-3"
                      value={jenkinsConfig.url}
                      onChange={(e) => setJenkinsConfig({...jenkinsConfig, url: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="username" className="text-right">
                      Username <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="username"
                      placeholder="admin"
                      className="col-span-3"
                      value={jenkinsConfig.username}
                      onChange={(e) => setJenkinsConfig({...jenkinsConfig, username: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="apiToken" className="text-right">
                      API Token <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="apiToken"
                      type="password"
                      placeholder="your-api-token"
                      className="col-span-3"
                      value={jenkinsConfig.apiToken}
                      onChange={(e) => setJenkinsConfig({...jenkinsConfig, apiToken: e.target.value})}
                    />
                  </div>
                  {connectionError && (
                    <div className="col-span-4 text-red-600 text-sm bg-red-50 p-2 rounded">
                      <div className="font-medium mb-1">Connection Error:</div>
                      <div>{connectionError}</div>
                      <div className="mt-2 text-xs">
                        <strong>Troubleshooting tips:</strong>
                        <ul className="list-disc list-inside mt-1 space-y-1">
                          <li>Ensure Jenkins is running and accessible</li>
                          <li>Check if the URL is correct (include http:// or https://)</li>
                          <li>Verify your username and API token</li>
                          <li>Check if Jenkins has CORS enabled for this domain</li>
                          <li>Try accessing Jenkins directly in your browser</li>
                        </ul>
                      </div>
                    </div>
                  )}
                  <div className="col-span-4 text-sm text-gray-600">
                    <p className="mb-2">
                      <strong>How to get your Jenkins API Token:</strong>
                    </p>
                    <ol className="list-decimal list-inside space-y-1 text-xs">
                      <li>Log in to your Jenkins server</li>
                      <li>Click on your username in the top right corner</li>
                      <li>Click on "Configure"</li>
                      <li>Click "Add new Token" under "API Token"</li>
                      <li>Copy the generated token</li>
                    </ol>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <Button variant="outline" onClick={() => setConfigOpen(false)}>
                    Cancel
                  </Button>
                  <div className="flex items-center gap-2">
                    {connectionStatus === 'connecting' && (
                      <Clock className="h-4 w-4 animate-spin" />
                    )}
                    <Badge className={getConnectionColor()}>
                      {connectionStatus === 'connected' && 'Connected'}
                      {connectionStatus === 'connecting' && 'Connecting...'}
                      {connectionStatus === 'error' && 'Connection Failed'}
                      {connectionStatus === 'disconnected' && 'Not Connected'}
                    </Badge>
                    <Button onClick={handleSaveConfig} disabled={connectionStatus === 'connecting'}>
                      {connectionStatus === 'connecting' ? 'Connecting...' : 'Connect & Save'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            )}
          </CardContent>
        </Card>
      )}

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-3xl font-bold">Jenkins Pipeline Monitor</h1>
          <div className="flex items-center gap-2">
            {getConnectionIcon()}
            <Badge variant={useMockData ? "secondary" : "default"}>
              {useMockData ? "Demo Mode" : "Connected"}
            </Badge>
            <div className="flex items-center gap-1">
              {websocket.connected ? (
                <Wifi className="h-4 w-4 text-green-500" />
              ) : (
                <WifiOff className="h-4 w-4 text-gray-500" />
              )}
              <span className="text-xs text-muted-foreground">
                {websocket.connected ? 'Live' : 'Offline'}
              </span>
            </div>
            {websocket.notifications.length > 0 && (
              <div className="flex items-center gap-1">
                <Bell className="h-4 w-4 text-blue-500" />
                <span className="text-xs text-muted-foreground">
                  {websocket.notifications.length}
                </span>
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-4">
          {!useMockData && (
            <>
              <Dialog open={configOpen} onOpenChange={setConfigOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4" />
                    Jenkins Settings
                  </Button>
                </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Jenkins Configuration</DialogTitle>
                  <DialogDescription>
                    Update your Jenkins server connection settings.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="url" className="text-right">
                      Jenkins URL
                    </Label>
                    <Input
                      id="url"
                      placeholder="https://jenkins.example.com"
                      className="col-span-3"
                      value={jenkinsConfig.url}
                      onChange={(e) => setJenkinsConfig({...jenkinsConfig, url: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="username" className="text-right">
                      Username
                    </Label>
                    <Input
                      id="username"
                      placeholder="admin"
                      className="col-span-3"
                      value={jenkinsConfig.username}
                      onChange={(e) => setJenkinsConfig({...jenkinsConfig, username: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="apiToken" className="text-right">
                      API Token
                    </Label>
                    <Input
                      id="apiToken"
                      type="password"
                      placeholder="your-api-token"
                      className="col-span-3"
                      value={jenkinsConfig.apiToken}
                      onChange={(e) => setJenkinsConfig({...jenkinsConfig, apiToken: e.target.value})}
                    />
                  </div>
                  {connectionError && (
                    <div className="col-span-4 text-red-600 text-sm bg-red-50 p-2 rounded">
                      {connectionError}
                    </div>
                  )}
                </div>
                <div className="flex justify-between items-center">
                  <Button variant="outline" onClick={() => setConfigOpen(false)}>
                    Cancel
                  </Button>
                  <div className="flex items-center gap-2">
                    {connectionStatus === 'connecting' && (
                      <Clock className="h-4 w-4 animate-spin" />
                    )}
                    <Badge className={getConnectionColor()}>
                      {connectionStatus === 'connected' && 'Connected'}
                      {connectionStatus === 'connecting' && 'Connecting...'}
                      {connectionStatus === 'error' && 'Connection Failed'}
                      {connectionStatus === 'disconnected' && 'Not Connected'}
                    </Badge>
                    <Button onClick={handleSaveConfig} disabled={connectionStatus === 'connecting'}>
                      {connectionStatus === 'connecting' ? 'Connecting...' : 'Update Settings'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            
            <Dialog open={ollamaConfigOpen} onOpenChange={setOllamaConfigOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Bot className="h-4 w-4" />
                  AI Settings
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>AI Configuration</DialogTitle>
                  <DialogDescription>
                    Configure Ollama for AI-powered Jenkins issue resolution
                  </DialogDescription>
                </DialogHeader>
                <OllamaSettings 
                  onConfigChange={(config) => setOllamaConfig(config)}
                  onClose={() => setOllamaConfigOpen(false)}
                />
              </DialogContent>
            </Dialog>
            </>
          )}
          
          <Button
            variant="outline"
            onClick={() => setAutoRefresh(!autoRefresh)}
            className="flex items-center gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${autoRefresh ? 'animate-spin' : ''}`} />
            Auto Refresh {autoRefresh ? 'On' : 'Off'}
          </Button>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon">
            <Search className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pipelines</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pipelines.length}</div>
            <p className="text-xs text-muted-foreground">
              {pipelines.filter(p => p.status === 'running').length} running
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Failed Today</CardTitle>
            <XCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {stats?.totalFailures || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              {stats?.failureRate || 0}% failure rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Resolution Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats?.avgResolutionTime || 0}m
            </div>
            <p className="text-xs text-muted-foreground">
              Time to fix issues
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {100 - (stats?.failureRate || 0)}%
            </div>
            <Progress value={100 - (stats?.failureRate || 0)} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pipelines" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pipelines">Active Pipelines</TabsTrigger>
          <TabsTrigger value="failures">Common Failures</TabsTrigger>
          <TabsTrigger value="solutions">Quick Solutions</TabsTrigger>
        </TabsList>

        <TabsContent value="pipelines" className="space-y-4">
          <div className="grid gap-4">
            {pipelines.map((pipeline) => (
              <Card key={pipeline.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(pipeline.status)}
                      <CardTitle className="text-lg">{pipeline.name}</CardTitle>
                      <Badge className={getStatusColor(pipeline.status)}>
                        {pipeline.status}
                      </Badge>
                      {pipeline.buildNumber && (
                        <Badge variant="outline" className="text-xs">
                          #{pipeline.buildNumber}
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {pipeline.duration}m
                    </div>
                  </div>
                  <CardDescription>
                    {pipeline.developer} • {pipeline.branch} • Started {new Date(pipeline.startTime).toLocaleTimeString()}
                    {pipeline.buildUrl && (
                      <span className="block text-xs text-blue-600 hover:text-blue-800 cursor-pointer">
                        <a href={pipeline.buildUrl} target="_blank" rel="noopener noreferrer">
                          View in Jenkins →
                        </a>
                      </span>
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {pipeline.failureStage && (
                    <Alert className="mb-4">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Failed at:</strong> {pipeline.failureStage}
                        <br />
                        <strong>Reason:</strong> {pipeline.failureReason}
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Pipeline Stages</div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
                      {pipeline.stages.map((stage) => (
                        <div key={stage.id} className="flex items-center gap-2 p-2 border rounded">
                          {getStatusIcon(stage.status)}
                          <span className="text-sm">{stage.name}</span>
                          <span className="text-xs text-muted-foreground ml-auto">
                            {stage.duration}m
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {(pipeline.status === 'failed' || pipeline.status === 'running') && (
                    <div className="mt-4 flex gap-2">
                      {pipeline.status === 'running' && (
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleStopPipeline(pipeline.id)}
                        >
                          Stop
                        </Button>
                      )}
                      {pipeline.status === 'failed' && (
                        <Button 
                          size="sm" 
                          onClick={() => handleQuickFix(pipeline.id)}
                          className={ollamaConfig.enabled ? "bg-purple-600 hover:bg-purple-700" : "bg-blue-600 hover:bg-blue-700"}
                        >
                          {ollamaConfig.enabled ? (
                            <>
                              <Brain className="mr-1 h-3 w-3" />
                              AI Quick Fix
                            </>
                          ) : (
                            <>
                              <Zap className="mr-1 h-3 w-3" />
                              Quick Fix
                            </>
                          )}
                        </Button>
                      )}
                      <Button size="sm" variant="outline" onClick={() => handleViewLogs(pipeline.id)}>
                        View Logs
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleRestartPipeline(pipeline.id)}>
                        Restart
                      </Button>
                      {/* Debug buttons - temporary for troubleshooting */}
                      <Button size="sm" variant="destructive" onClick={() => handleDebugLogs(pipeline.id)}>
                        Debug Logs
                      </Button>
                      <Button size="sm" variant="secondary" onClick={() => handleDownloadLogs(pipeline.id)}>
                        Download Logs
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="failures" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Common Failure Patterns</CardTitle>
                  <CardDescription>
                    Most frequent pipeline failures and their solutions
                  </CardDescription>
                </div>
                {ollamaConfig.enabled && (
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={async () => {
                      try {
                        const failures = stats?.commonFailures || []
                        const response = await fetch('/api/ollama', {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify({
                            action: 'analyze-failure',
                            failureReason: 'Multiple failure patterns detected',
                            logs: failures.map(f => `${f.reason}: ${f.solution}`),
                            jobName: 'system-analysis',
                            buildNumber: 1,
                            config: ollamaConfig
                          })
                        })

                        const result = await response.json()
                        if (result.success) {
                          alert('AI analysis complete! Check the console for detailed insights.')
                          console.log('AI Failure Analysis:', result.analysis)
                        } else {
                          alert('AI analysis failed: ' + result.error)
                        }
                      } catch (error) {
                        console.error('AI failure analysis failed:', error)
                        alert('AI analysis failed: ' + (error instanceof Error ? error.message : 'Unknown error'))
                      }
                    }}
                  >
                    <Brain className="mr-1 h-3 w-3" />
                    AI Analyze All
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stats?.commonFailures.map((failure, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{failure.reason}</h4>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{failure.count} occurrences</Badge>
                        {ollamaConfig.enabled && (
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={async () => {
                              try {
                                const response = await fetch('/api/ollama', {
                                  method: 'POST',
                                  headers: {
                                    'Content-Type': 'application/json',
                                  },
                                  body: JSON.stringify({
                                    action: 'analyze-failure',
                                    failureReason: failure.reason,
                                    logs: [failure.solution],
                                    jobName: 'failure-analysis',
                                    buildNumber: 1,
                                    config: ollamaConfig
                                  })
                                })

                                const result = await response.json()
                                if (result.success) {
                                  alert(`AI Analysis for "${failure.reason}":\n\n${result.analysis.explanation}`)
                                } else {
                                  alert('AI analysis failed: ' + result.error)
                                }
                              } catch (error) {
                                console.error('AI analysis failed:', error)
                                alert('AI analysis failed: ' + (error instanceof Error ? error.message : 'Unknown error'))
                              }
                            }}
                          >
                            <Brain className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {failure.solution}
                    </p>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        Apply Fix Template
                      </Button>
                      {ollamaConfig.enabled && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={async () => {
                            try {
                              const response = await fetch('/api/ollama', {
                                method: 'POST',
                                headers: {
                                  'Content-Type': 'application/json',
                                },
                                body: JSON.stringify({
                                  action: 'generate-solution',
                                  problem: failure.reason,
                                  context: failure.solution,
                                  existingSolutions: [failure],
                                  config: ollamaConfig
                                })
                              })

                              const result = await response.json()
                              if (result.success) {
                                alert('AI-enhanced solution generated! Check the console for details.')
                                console.log('AI Enhanced Solution:', result.solution)
                              } else {
                                alert('AI solution generation failed: ' + result.error)
                              }
                            } catch (error) {
                              console.error('AI solution generation failed:', error)
                              alert('AI solution generation failed: ' + (error instanceof Error ? error.message : 'Unknown error'))
                            }
                          }}
                        >
                          <Bot className="mr-1 h-3 w-3" />
                          Enhance Solution
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="solutions" className="space-y-4">
          <div className="grid gap-4">
            {/* AI-Powered Solutions Section */}
            {ollamaConfig.enabled && (
              <Card className="border-purple-200 bg-purple-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-800">
                    <Brain className="h-5 w-5" />
                    AI-Powered Solutions
                  </CardTitle>
                  <CardDescription className="text-purple-700">
                    Leverage AI to analyze failures and generate intelligent solutions
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid gap-4">
                  <Button 
                    className="justify-start" 
                    variant="outline"
                    onClick={async () => {
                      try {
                        // Get failure data for AI analysis
                        const failures = stats?.commonFailures || []
                        const response = await fetch('/api/ollama', {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify({
                            action: 'improve-knowledge',
                            failures: failures,
                            solutions: [], // Would fetch from knowledge base
                            patterns: [], // Would fetch from pattern recognition
                            config: ollamaConfig
                          })
                        })

                        const result = await response.json()
                        if (result.success) {
                          alert('AI analysis complete! Check the console for details.')
                          console.log('AI Knowledge Base Improvements:', result.improvements)
                        } else {
                          alert('AI analysis failed: ' + result.error)
                        }
                      } catch (error) {
                        console.error('AI knowledge analysis failed:', error)
                        alert('AI analysis failed: ' + (error instanceof Error ? error.message : 'Unknown error'))
                      }
                    }}
                  >
                    <Brain className="mr-2 h-4 w-4" />
                    Analyze Failure Patterns
                  </Button>
                  
                  <Button 
                    className="justify-start" 
                    variant="outline"
                    onClick={async () => {
                      try {
                        const response = await fetch('/api/ollama', {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify({
                            action: 'generate-solution',
                            problem: 'Pipeline timeout issues',
                            context: 'Jenkins pipelines frequently timeout during test execution',
                            existingSolutions: stats?.commonFailures || [],
                            config: ollamaConfig
                          })
                        })

                        const result = await response.json()
                        if (result.success) {
                          alert('AI solution generated! Check the console for details.')
                          console.log('AI Generated Solution:', result.solution)
                        } else {
                          alert('AI solution generation failed: ' + result.error)
                        }
                      } catch (error) {
                        console.error('AI solution generation failed:', error)
                        alert('AI solution generation failed: ' + (error instanceof Error ? error.message : 'Unknown error'))
                      }
                    }}
                  >
                    <Bot className="mr-2 h-4 w-4" />
                    Generate Custom Solution
                  </Button>

                  <div className="p-3 bg-white rounded border">
                    <h4 className="font-medium text-sm mb-2">AI Capabilities:</h4>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      <li>• Root cause analysis from failure patterns</li>
                      <li>• Custom solution generation based on context</li>
                      <li>• Knowledge base gap identification</li>
                      <li>• Automated solution optimization</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>
                  Common solutions for frequent pipeline issues
                </CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4">
                <Button className="justify-start" variant="outline">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Restart All Failed Pipelines
                </Button>
                <Button className="justify-start" variant="outline">
                  <Filter className="mr-2 h-4 w-4" />
                  Clear Build Cache
                </Button>
                <Button className="justify-start" variant="outline">
                  <Settings className="mr-2 h-4 w-4" />
                  Update Jenkins Plugins
                </Button>
                <Button className="justify-start" variant="outline">
                  <Search className="mr-2 h-4 w-4" />
                  Run System Diagnostics
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Automation Rules</CardTitle>
                <CardDescription>
                  Configure automated responses to common failures
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <div className="font-medium">Test Timeout</div>
                        <div className="text-sm text-muted-foreground">
                          Auto-retry with increased timeout
                        </div>
                      </div>
                      <Button size="sm" variant="outline">Edit</Button>
                    </div>
                    <div className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <div className="font-medium">Memory Issues</div>
                        <div className="text-sm text-muted-foreground">
                          Auto-scale resources and retry
                        </div>
                      </div>
                      <Button size="sm" variant="outline">Edit</Button>
                    </div>
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Log Viewer Dialog */}
      {isMounted && (
        <Dialog open={logViewerOpen} onOpenChange={setLogViewerOpen}>
          <DialogContent className="max-w-6xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle>Build Logs</DialogTitle>
              <DialogDescription>
                View detailed logs for {selectedPipeline?.name} pipeline execution
              </DialogDescription>
            </DialogHeader>
            {selectedPipeline && (
              <LogViewer
                pipelineId={selectedPipeline.id}
                pipelineName={selectedPipeline.name}
                buildNumber={selectedPipeline.buildNumber}
                logs={selectedPipeline.stages.flatMap(s => s.logs)}
                onClose={() => setLogViewerOpen(false)}
              />
            )}
          </DialogContent>
        </Dialog>
      )}

      {/* AI Fix Preview Dialog */}
      <AIFixPreview
        isOpen={aiFixPreviewOpen}
        onClose={() => setAiFixPreviewOpen(false)}
        pipelineName={currentPipelineForFix?.name || ''}
        analysis={currentAIAnalysis || {}}
        onConfirm={handleConfirmAIFix}
        onReject={handleRejectAIFix}
      />
    </div>
  )
}