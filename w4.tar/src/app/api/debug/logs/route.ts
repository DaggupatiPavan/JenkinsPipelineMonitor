import { NextRequest, NextResponse } from 'next/server'
import { jenkinsService } from '@/lib/jenkins'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const jobName = searchParams.get('jobName')
    const buildNumber = searchParams.get('buildNumber')
    const jenkinsUrl = searchParams.get('url')
    const username = searchParams.get('username')
    const apiToken = searchParams.get('apiToken')

    if (!jobName || !jenkinsUrl || !username || !apiToken) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      )
    }

    // Set configuration for this request
    jenkinsService.setConfig({
      url: jenkinsUrl,
      username,
      apiToken
    })

    let actualBuildNumber = buildNumber
    
    if (!actualBuildNumber) {
      // Get latest build number if not provided
      const jobs = await jenkinsService.getJobs()
      const job = jobs.find(j => j.name === jobName)
      
      if (job && job.lastBuild) {
        actualBuildNumber = String(job.lastBuild.number)
      }
    }

    const debugInfo = {
      jobName,
      requestedBuildNumber: buildNumber,
      actualBuildNumber,
      jenkinsUrl,
      username: username + '***', // Mask username for security
      hasApiToken: !!apiToken
    }

    if (!actualBuildNumber) {
      return NextResponse.json({
        debugInfo,
        error: 'No build number found',
        jobs: await jenkinsService.getJobs()
      })
    }

    // Try to get the raw logs
    try {
      const rawLogs = await jenkinsService.getBuildLog(jobName, parseInt(actualBuildNumber))
      
      // Try to get build details
      let buildDetails = null
      try {
        buildDetails = await jenkinsService.getBuildDetails(jobName, parseInt(actualBuildNumber))
      } catch (detailsError) {
        console.error('Failed to get build details:', detailsError)
      }

      return NextResponse.json({
        debugInfo,
        buildDetails,
        rawLogs: rawLogs.substring(0, 5000) + (rawLogs.length > 5000 ? '...[truncated]' : ''), // Limit response size
        logLength: rawLogs.length,
        logPreview: rawLogs.split('\n').slice(0, 10) // First 10 lines
      })
    } catch (logError) {
      return NextResponse.json({
        debugInfo,
        error: 'Failed to fetch logs',
        logError: logError instanceof Error ? logError.message : String(logError)
      })
    }
  } catch (error) {
    console.error('Debug logs error:', error)
    return NextResponse.json(
      { 
        error: 'Debug endpoint failed',
        details: error instanceof Error ? error.message : String(error)
      },
      { status: 500 }
    )
  }
}