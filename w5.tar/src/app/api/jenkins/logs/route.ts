import { NextRequest, NextResponse } from 'next/server'
import { jenkinsService, JenkinsService } from '@/lib/jenkins'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const jobName = searchParams.get('jobName')
    const buildNumber = searchParams.get('buildNumber')
    const jenkinsUrl = searchParams.get('url')
    const username = searchParams.get('username')
    const apiToken = searchParams.get('apiToken')

    if (!jobName || !buildNumber || !jenkinsUrl || !username || !apiToken) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      )
    }

    // Set configuration for this request
    jenkinsService.setConfig({
      url: jenkinsUrl,
      username,
      apiToken
    })

    const logs = await jenkinsService.getBuildLog(jobName, parseInt(buildNumber))
    
    return NextResponse.json({ logs })
  } catch (error) {
    console.error('Error fetching Jenkins build logs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch build logs' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { jobName, buildNumber, jenkinsUrl, username, apiToken } = await request.json()

    if (!jobName) {
      return NextResponse.json(
        { error: 'Missing job name' },
        { status: 400 }
      )
    }

    // Use environment variables if not provided
    const url = jenkinsUrl || process.env.NEXT_PUBLIC_JENKINS_URL
    const user = username || process.env.NEXT_PUBLIC_JENKINS_USERNAME
    const token = apiToken || process.env.NEXT_PUBLIC_JENKINS_API_TOKEN

    if (!url || !user || !token) {
      return NextResponse.json(
        { error: 'Missing Jenkins configuration' },
        { status: 400 }
      )
    }

    // Set configuration for this request
    jenkinsService.setConfig({
      url,
      username: user,
      apiToken: token
    })

    let stages = []
    let actualBuildNumber = buildNumber
    
    if (!actualBuildNumber) {
      // Get latest build number if not provided
      const jobs = await jenkinsService.getJobs()
      const job = jobs.find(j => j.name === jobName)
      
      if (job && job.lastBuild) {
        actualBuildNumber = job.lastBuild.number
      }
    }
    
    if (actualBuildNumber) {
      // Get logs for specific build
      const logs = await jenkinsService.getBuildLog(jobName, parseInt(actualBuildNumber))
      const buildDetails = await jenkinsService.getBuildDetails(jobName, parseInt(actualBuildNumber))
      
      stages = buildDetails.stages?.map(stage => ({
        id: `${jobName}-${actualBuildNumber}-${stage.name}`,
        name: stage.name,
        status: JenkinsService.convertBuildStatus(stage.status, false),
        duration: Math.floor(stage.durationMillis / 60000),
        logs: [logs] // Include the full build logs for this stage
      })) || []
    } else {
      // Fallback if no build number found
      stages = [{
        id: `${jobName}-no-build`,
        name: 'No Build Found',
        status: 'pending' as const,
        duration: 0,
        logs: ['No build history found for this job']
      }]
    }

    return NextResponse.json({ 
      success: true,
      jobName,
      buildNumber: actualBuildNumber || 'latest',
      stages,
      downloadUrl: `/api/jenkins/logs?jobName=${encodeURIComponent(jobName)}&buildNumber=${actualBuildNumber || 'latest'}&url=${encodeURIComponent(url)}&username=${encodeURIComponent(user)}&apiToken=${encodeURIComponent(token)}`
    })
  } catch (error) {
    console.error('Error fetching Jenkins logs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch logs' },
      { status: 500 }
    )
  }
}