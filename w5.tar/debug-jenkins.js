#!/usr/bin/env node

// Debug script to test Jenkins connection step by step
// 
// IMPORTANT: Before running this script:
// 1. Get your Jenkins API token from Jenkins UI
// 2. Replace 'REPLACE_WITH_YOUR_JENKINS_API_TOKEN' below with your actual token
// 3. Run: node debug-jenkins.js
//
const https = require('https');
const http = require('http');

// Your Jenkins configuration - WORKING CONFIGURATION
const config = {
  url: 'http://20.121.40.237:8080',
  username: 'admin',
  apiToken: '115219a84ac43df5537ed94c7abad9fd55' // This is the working API token
};

function makeRequest(path, description) {
  return new Promise((resolve, reject) => {
    console.log(`\n🔍 Testing: ${description}`);
    console.log(`📍 URL: ${config.url}${path}`);
    
    const url = new URL(config.url);
    const auth = Buffer.from(`${config.username}:${config.apiToken}`).toString('base64');
    
    const options = {
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: path,
      method: 'GET',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json',
        'User-Agent': 'JenkinsPipelineMonitor/1.0'
      },
      timeout: 15000
    };

    const client = url.protocol === 'https:' ? https : http;

    const req = client.request(options, (res) => {
      console.log(`📊 Status: ${res.statusCode} ${res.statusMessage}`);
      console.log(`📋 Headers:`, JSON.stringify(res.headers, null, 2));
      
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          console.log('✅ Response parsed successfully');
          resolve({ status: res.statusCode, headers: res.headers, data: parsed });
        } catch (e) {
          console.log('⚠️  Response is not JSON');
          resolve({ status: res.statusCode, headers: res.headers, data: data });
        }
      });
    });

    req.on('error', (error) => {
      console.error('❌ Request failed:', error.message);
      reject(error);
    });

    req.on('timeout', () => {
      console.log('⏰ Request timed out');
      req.destroy();
      reject(new Error('Timeout'));
    });

    req.end();
  });
}

async function debugJenkins() {
  console.log('🚀 Starting Jenkins Connection Debug');
  console.log('=====================================');
  
  // Check if API token has been replaced
  if (config.apiToken === 'REPLACE_WITH_YOUR_JENKINS_API_TOKEN') {
    console.log('❌ ERROR: Please replace the API token in debug-jenkins.js');
    console.log('');
    console.log('Steps to get your Jenkins API token:');
    console.log('1. Log in to Jenkins at: http://20.121.40.237:8080');
    console.log('2. Click on your username in the top-right corner');
    console.log('3. Click "Configure" in the left sidebar');
    console.log('4. Scroll down to "API Token" section');
    console.log('5. Click "Add new Token" and enter a name');
    console.log('6. Click "Generate" and copy the token immediately');
    console.log('7. Replace the placeholder in this script');
    console.log('');
    console.log('Then run: node debug-jenkins.js');
    return;
  }
  
  try {
    // Test 1: Basic Jenkins info
    await makeRequest('/api/json?tree=description', 'Basic Jenkins API');
    
    // Test 2: Get jobs list
    await makeRequest('/api/json?tree=jobs[name,url,color,lastBuild[number,url,timestamp,duration,result,building]]', 'Jobs List');
    
    // Test 3: Get specific job details
    await makeRequest('/job/test/api/json?tree=name,url,color,lastBuild[number,url,timestamp,duration,result,building]', 'Job Details (test)');
    
    // Test 4: Test without authentication
    console.log('\n🔍 Testing: Without Authentication');
    const url = new URL(config.url);
    const options = {
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: '/api/json?tree=description',
      method: 'GET',
      timeout: 10000
    };

    const client = url.protocol === 'https:' ? https : http;
    
    const req = client.request(options, (res) => {
      console.log(`📊 Status (no auth): ${res.statusCode} ${res.statusMessage}`);
      if (res.statusCode === 403) {
        console.log('✅ Jenkins requires authentication (good security!)');
      } else if (res.statusCode === 200) {
        console.log('⚠️  Jenkins allows anonymous access (security concern)');
      }
      res.resume();
    });
    
    req.end();
    
  } catch (error) {
    console.error('💥 Debug failed:', error.message);
  }
}

// Run the debug
debugJenkins();