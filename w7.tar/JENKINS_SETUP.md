# 🔧 Jenkins Connection Setup Guide

## 📋 Prerequisites

Before setting up the Jenkins connection, ensure you have:

1. **Jenkins Server Access**: URL, username, and password
2. **Jenkins API Token**: Generated from your Jenkins user account
3. **Network Access**: Ability to reach Jenkins from the application server

## 🚀 Step-by-Step Setup

### 1. Get Your Jenkins API Token

1. **Log in to Jenkins** (http://20.121.40.237:8080)
2. **Click on your username** in the top-right corner
3. **Click "Configure"** on the left sidebar
4. **Scroll down to "API Token"** section
5. **Click "Add new Token"**
6. **Enter a token name** (e.g., "pipeline-monitor")
7. **Click "Generate"**
8. **Copy the token immediately** (it won't be shown again)

### 2. Configure Environment Variables

Create or update your `.env.local` file:

```bash
# Jenkins Configuration
NEXT_PUBLIC_JENKINS_URL=http://20.121.40.237:8080
NEXT_PUBLIC_JENKINS_USERNAME=admin
NEXT_PUBLIC_JENKINS_API_TOKEN=your-generated-api-token

# Other configurations...
NEXT_PUBLIC_OLLAMA_BASE_URL=http://localhost:11434
NEXT_PUBLIC_OLLAMA_MODEL=llama3.2
DATABASE_URL=file:/home/z/my-project/db/custom.db
```

**Replace `your-generated-api-token` with the actual token you copied.**

### 3. Test the Connection

#### Option A: Using the Debug Script

1. **Update the debug script** with your API token:
   ```bash
   # Edit debug-jenkins.js
   nano debug-jenkins.js
   ```
2. **Replace the placeholder token** with your actual token
3. **Run the debug script**:
   ```bash
   node debug-jenkins.js
   ```

#### Option B: Using curl

```bash
# Test basic connection
curl -u "admin:your-api-token" \
  -H "Content-Type: application/json" \
  -H "X-Requested-With: XMLHttpRequest" \
  http://20.121.40.237:8080/api/json?tree=description

# Test jobs endpoint
curl -u "admin:your-api-token" \
  -H "Content-Type: application/json" \
  -H "X-Requested-With: XMLHttpRequest" \
  http://20.121.40.237:8080/api/json?tree=jobs[name,url,color,lastBuild[number,url,timestamp,duration,result,building]]
```

### 4. Configure Jenkins for CORS (if needed)

If you're getting CORS errors, you need to configure Jenkins:

1. **Install CORS Plugin** (if not already installed):
   - Go to `Manage Jenkins` → `Manage Plugins`
   - Click `Available` tab
   - Search for "CORS"
   - Install "CORS Plugin"

2. **Configure CORS**:
   - Go to `Manage Jenkins` → `Configure Global Security`
   - Find the CORS section
   - Add the following configuration:
     ```
     Access-Control-Allow-Origin: *
     Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
     Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Requested-With
     Access-Control-Max-Age: 3600
     ```

### 5. Configure CSRF Protection (if needed)

If you're getting CSRF errors:

1. **Go to** `Manage Jenkins` → `Configure Global Security`
2. **Find "Prevent Cross Site Request Forgery exploits"**
3. **Either**:
   - **Uncheck it** (for testing, not recommended for production)
   - **Configure it properly** by adding your application domain to allowed list

### 6. Restart the Application

After configuring the environment variables:

```bash
# Restart the development server
npm run dev
```

## 🔍 Troubleshooting Common Issues

### Issue 1: "Authentication failed"

**Symptoms**: Getting 401 Unauthorized errors

**Solutions**:
1. **Verify API token**: Generate a fresh token
2. **Check username**: Ensure it's exactly as in Jenkins
3. **Test with curl**: Verify credentials work directly

### Issue 2: "CORS error"

**Symptoms**: Getting CORS-related errors in browser console

**Solutions**:
1. **Install CORS plugin**: Ensure it's installed and enabled
2. **Configure CORS headers**: Add proper CORS configuration
3. **Check Jenkins logs**: Look for CORS-related errors

### Issue 3: "Network error"

**Symptoms**: Connection timeout or refused

**Solutions**:
1. **Check Jenkins URL**: Ensure it's accessible
2. **Verify network connectivity**: Test from application server
3. **Check firewall**: Ensure port 8080 is open

### Issue 4: "CSRF error"

**Symptoms**: Getting 403 Forbidden with CSRF message

**Solutions**:
1. **Disable CSRF**: For testing (not production)
2. **Configure CSRF**: Add application domain to allowed list
3. **Use crumb issuer**: Implement proper CSRF handling

## 🧪 Testing Checklist

Before using the application, verify:

- [ ] **API token works** with curl
- [ ] **Basic Jenkins API** returns data
- [ ] **Jobs endpoint** returns job list
- [ ] **No CORS errors** in browser
- [ ] **No authentication errors** in logs
- [ ] **Application connects** successfully

## 📝 Example Working Configuration

Here's an example of a working `.env.local` file:

```env
# Jenkins Configuration
NEXT_PUBLIC_JENKINS_URL=http://20.121.40.237:8080
NEXT_PUBLIC_JENKINS_USERNAME=admin
NEXT_PUBLIC_JENKINS_API_TOKEN=11a5a9e5c0b0d5b5e5c5d5e5f5a5b5c5d

# Ollama Configuration
NEXT_PUBLIC_OLLAMA_BASE_URL=http://localhost:11434
NEXT_PUBLIC_OLLAMA_MODEL=llama3.2

# Database Configuration
DATABASE_URL=file:/home/z/my-project/db/custom.db

# Next.js Configuration
NEXTAUTH_SECRET=your-nextauth-secret-here
NEXTAUTH_URL=http://localhost:3000

# Application Configuration
NODE_ENV=development
PORT=3000
```

## 🚀 Next Steps

Once the connection is working:

1. **Open the application**: http://localhost:3000
2. **Verify connection status**: Should show "Connected"
3. **Check job list**: Should show your Jenkins jobs
4. **Test real-time updates**: Jobs should update automatically

## 🆘 Getting Help

If you're still having issues:

1. **Check the debug script output**: Run `node debug-jenkins.js`
2. **Review Jenkins logs**: Check for errors
3. **Test with curl**: Verify direct API access
4. **Check browser console**: Look for JavaScript errors

---

**Remember**: The most common issue is incorrect API token. Always generate a fresh token and test it directly before using it in the application!