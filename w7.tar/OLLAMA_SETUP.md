# Ollama Setup Guide for Jenkins Pipeline Monitor

This guide explains how to set up Ollama for AI-powered features in the Jenkins Pipeline Monitor application.

## Problem

The AI analysis features in the Jenkins Pipeline Monitor are failing with timeout errors because Ollama is not installed or running on the system.

## Solution Options

### Option 1: Local Installation (Recommended)

#### Prerequisites
- Linux system (recommended) or macOS
- sudo access (for Linux)
- At least 8GB RAM (16GB recommended for better performance)
- 10GB+ free disk space for models

#### Installation Steps

1. **Run the setup script** (if available):
   ```bash
   ./setup-ollama.sh
   ```

2. **Manual installation**:

   **For Linux:**
   ```bash
   # Install Ollama
   curl -fsSL https://ollama.com/install.sh | sh
   
   # Start the service
   sudo systemctl start ollama
   sudo systemctl enable ollama
   
   # Download the required model
   ollama pull llama3.2
   ```

   **For macOS:**
   ```bash
   # Install using Homebrew
   brew install ollama
   
   # Start Ollama
   ollama serve
   
   # In a separate terminal, download the model
   ollama pull llama3.2
   ```

3. **Verify installation**:
   ```bash
   # Check if Ollama is running
   ollama ps
   
   # List available models
   ollama list
   
   # Test the API
   curl http://localhost:11434/api/tags
   ```

### Option 2: Docker Setup

1. **Start Ollama with Docker**:
   ```bash
   docker-compose -f docker-compose.ollama.yml up -d
   ```

2. **Download the model**:
   ```bash
   docker exec jenkins-ollama ollama pull llama3.2
   ```

3. **Check status**:
   ```bash
   docker-compose -f docker-compose.ollama.yml ps
   docker exec jenkins-ollama ollama list
   ```

### Option 3: Remote Ollama Server

If you have Ollama running on a different server:

1. **Update environment variables** in `.env.local`:
   ```bash
   NEXT_PUBLIC_OLLAMA_BASE_URL=http://your-ollama-server:11434
   NEXT_PUBLIC_OLLAMA_MODEL=llama3.2
   ```

2. **Ensure the remote server is accessible** from your application server.

## Configuration

### Environment Variables

Update your `.env.local` file:

```bash
# Ollama Configuration
NEXT_PUBLIC_OLLAMA_BASE_URL=http://localhost:11434
NEXT_PUBLIC_OLLAMA_MODEL=llama3.2
```

### Application Settings

1. **Start the Jenkins Pipeline Monitor application**
2. **Navigate to Settings → Ollama AI Integration**
3. **Enable Ollama Integration**
4. **Click "Test Connection"** to verify the setup
5. **Adjust timeout settings** if needed (default: 120 seconds)

## Troubleshooting

### Common Issues

#### 1. "Connection refused" error
**Problem**: Ollama service is not running
**Solution**: 
```bash
# Start Ollama service
sudo systemctl start ollama
# or
ollama serve
```

#### 2. "Model not found" error
**Problem**: The specified model is not downloaded
**Solution**:
```bash
# Download the model
ollama pull llama3.2
```

#### 3. "Timeout" error
**Problem**: AI processing takes too long
**Solutions**:
- Increase timeout in Ollama settings (up to 300 seconds)
- Use a smaller model (e.g., `llama3.2` instead of larger models)
- Check system resources (CPU, RAM)

#### 4. "ECONNREFUSED" error
**Problem**: Cannot connect to Ollama server
**Solutions**:
- Verify Ollama is running: `ollama ps`
- Check firewall settings
- Verify the URL in configuration
- Test connection: `curl http://localhost:11434/api/tags`

### Useful Commands

```bash
# Check Ollama status
ollama ps

# List downloaded models
ollama list

# Download a model
ollama pull llama3.2

# Remove a model
ollama rm llama3.2

# View Ollama logs
sudo journalctl -u ollama -f

# Restart Ollama service
sudo systemctl restart ollama

# Test API connection
curl http://localhost:11434/api/tags

# Test model generation
curl -X POST http://localhost:11434/api/generate -d '{
  "model": "llama3.2",
  "prompt": "Hello, respond with OK",
  "stream": false
}'
```

## Model Recommendations

### For General Analysis
- **llama3.2**: Good balance of performance and resource usage
- **llama3.1**: Slightly larger, more capable

### For Code-Specific Analysis
- **codellama**: Optimized for code analysis and generation
- **deepseek-coder**: Excellent for programming tasks

### For Resource-Constrained Systems
- **phi3**: Small and fast, good for basic analysis
- **gemma**: Lightweight model from Google

## Performance Optimization

### System Requirements
- **RAM**: 8GB minimum, 16GB+ recommended
- **CPU**: 4 cores minimum, 8+ cores recommended
- **Disk**: 10GB+ free space for models

### Optimization Tips
1. **Use appropriate model size** for your hardware
2. **Increase timeout** for complex analysis tasks
3. **Monitor system resources** during AI operations
4. **Consider GPU acceleration** if available
5. **Limit concurrent requests** to avoid overload

## Security Considerations

1. **Network Access**: Ollama listens on all interfaces by default. Restrict access if needed.
2. **Model Security**: Only download models from trusted sources.
3. **API Security**: Consider adding authentication for production use.
4. **Data Privacy**: AI analysis may send sensitive data to the model. Ensure compliance with your security policies.

## Integration with Jenkins Pipeline Monitor

Once Ollama is set up, you can use these AI features:

- **Quick Solutions**: AI-powered fixes for common pipeline issues
- **AI-Powered Solutions**: Detailed analysis and recommendations
- **Analyze Failure Patterns**: Identify recurring issues
- **Generate Custom Solution**: Create tailored fixes
- **Improve and Enhance Code**: Code optimization suggestions

## Support

If you encounter issues:

1. Check the application logs for detailed error messages
2. Verify Ollama installation and status
3. Test the Ollama API directly
4. Consult the [Ollama documentation](https://ollama.com/docs)
5. Check system resources and requirements

---

**Note**: AI features require significant computational resources. Ensure your system meets the requirements before enabling these features in production.