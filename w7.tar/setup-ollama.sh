#!/bin/bash

# Setup script for Ollama AI integration
# This script installs Ollama and sets up the required model

set -e

echo "🤖 Setting up Ollama for Jenkins Pipeline Monitor AI features..."

# Check if Ollama is already installed
if command -v ollama &> /dev/null; then
    echo "✅ Ollama is already installed"
    OLLAMA_VERSION=$(ollama --version)
    echo "   Version: $OLLAMA_VERSION"
else
    echo "📦 Installing Ollama..."
    
    # Install Ollama based on the operating system
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        curl -fsSL https://ollama.com/install.sh | sh
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        echo "🍎 For macOS, please install Ollama manually:"
        echo "   Visit: https://ollama.com/download/macos"
        echo "   Or run: brew install ollama"
        exit 1
    else
        echo "❌ Unsupported operating system: $OSTYPE"
        echo "Please install Ollama manually from: https://ollama.com/download"
        exit 1
    fi
    
    echo "✅ Ollama installed successfully"
fi

# Check if Ollama service is running
if pgrep -f "ollama serve" > /dev/null; then
    echo "✅ Ollama service is already running"
else
    echo "🚀 Starting Ollama service..."
    
    # Start Ollama service
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        sudo systemctl start ollama
        sudo systemctl enable ollama
    else
        # For other systems, start ollama in background
        ollama serve &
        OLLAMA_PID=$!
        echo "   Ollama started with PID: $OLLAMA_PID"
    fi
    
    # Wait for service to start
    echo "⏳ Waiting for Ollama service to start..."
    sleep 5
    
    # Check if service is running
    if curl -s http://localhost:11434/api/tags > /dev/null; then
        echo "✅ Ollama service is running"
    else
        echo "❌ Failed to start Ollama service"
        echo "Please start it manually: ollama serve"
        exit 1
    fi
fi

# Download the required model
MODEL_NAME="llama3.2"
echo "📥 Downloading model: $MODEL_NAME..."

if ollama list | grep -q "$MODEL_NAME"; then
    echo "✅ Model $MODEL_NAME is already downloaded"
else
    echo "⏳ Downloading $MODEL_NAME... (this may take a few minutes)"
    ollama pull $MODEL_NAME
    echo "✅ Model $MODEL_NAME downloaded successfully"
fi

# Verify the setup
echo "🔍 Verifying Ollama setup..."

# Test connection
if curl -s http://localhost:11434/api/tags | jq -e '.models | length > 0' > /dev/null; then
    echo "✅ Ollama is working correctly"
    AVAILABLE_MODELS=$(curl -s http://localhost:11434/api/tags | jq -r '.models[].name' | tr '\n' ', ' | sed 's/,$//')
    echo "   Available models: $AVAILABLE_MODELS"
else
    echo "❌ Ollama verification failed"
    exit 1
fi

# Test model generation
echo "🧪 Testing model generation..."
TEST_RESPONSE=$(ollama run $MODEL_NAME "Hello, please respond with just the word 'OK'" 2>/dev/null || echo "")
if [[ "$TEST_RESPONSE" == *"OK"* ]]; then
    echo "✅ Model generation test successful"
else
    echo "⚠️  Model generation test failed, but setup may still be working"
fi

echo ""
echo "🎉 Ollama setup completed successfully!"
echo ""
echo "📋 Next steps:"
echo "   1. Start the Jenkins Pipeline Monitor application"
echo "   2. Go to Settings → Ollama AI Integration"
echo "   3. Enable Ollama integration"
echo "   4. Test the connection"
echo "   5. Use AI features for pipeline analysis"
echo ""
echo "🔧 Useful commands:"
echo "   ollama serve          - Start Ollama service"
echo "   ollama ps             - Check running models"
echo "   ollama list           - List downloaded models"
echo "   ollama pull <model>   - Download a new model"
echo "   ollama rm <model>     - Remove a model"
echo ""
echo "🌐 Ollama is running on: http://localhost:11434"
echo "📚 Documentation: https://ollama.com/docs"