// Fallback AI responses when Ollama is not available
// This provides mock responses for demonstration purposes

export interface AIAnalysis {
  rootCause: string
  errorPatterns: string[]
  immediateActions: string[]
  preventionStrategies: string[]
  confidence: 'High' | 'Medium' | 'Low'
  explanation: string
}

export interface AIFix {
  rootCause: string
  confidence: 'High' | 'Medium' | 'Low'
  immediateActions: string[]
  fileChanges: Array<{
    filePath: string
    changeType: 'modify' | 'create' | 'delete'
    description: string
    content?: string
  }>
  pipelineChanges: Array<{
    parameter: string
    oldValue: string
    newValue: string
    description: string
  }>
  riskAssessment: {
    level: 'low' | 'medium' | 'high'
    description: string
    mitigations: string[]
  }
}

export interface KnowledgeImprovement {
  gaps: string[]
  newSolutions: Array<{
    title: string
    description: string
    category: string
    severity: 'low' | 'medium' | 'high' | 'critical'
    problemPatterns: string[]
    estimatedFixTime: number
    successRate: number
  }>
  patterns: Array<{
    name: string
    description: string
    category: string
    frequency: number
  }>
  recommendations: string[]
  automation: string[]
}

// Mock AI analysis for common Jenkins failures
export function getMockAnalysis(failureReason: string, jobName: string): AIAnalysis {
  const analyses: Record<string, AIAnalysis> = {
    'Test timeout': {
      rootCause: 'Test execution timeout due to inefficient test cases and insufficient timeout configuration',
      errorPatterns: ['Test timeout after 10 minutes', 'JUnit test failure', 'Build step failed'],
      immediateActions: [
        'Increase test timeout from 10 minutes to 15 minutes',
        'Optimize test cases to reduce execution time',
        'Add parallel test execution',
        'Update test configuration file'
      ],
      preventionStrategies: [
        'Implement test performance monitoring',
        'Set up test timeout alerts',
        'Regular test suite optimization',
        'Use test slicing for large test suites'
      ],
      confidence: 'High',
      explanation: 'Analysis based on common timeout patterns in Jenkins pipelines. The issue is likely caused by tests taking longer than the configured timeout limit.'
    },
    'Memory limit exceeded': {
      rootCause: 'Jenkins build process exceeded allocated memory limit',
      errorPatterns: ['OutOfMemoryError', 'Memory limit exceeded', 'Heap space'],
      immediateActions: [
        'Increase JVM memory settings (-Xmx)',
        'Optimize build process memory usage',
        'Add memory monitoring to pipeline',
        'Split large build steps into smaller ones'
      ],
      preventionStrategies: [
        'Implement memory usage monitoring',
        'Set up memory alerts',
        'Regular performance tuning',
        'Use build caching strategies'
      ],
      confidence: 'High',
      explanation: 'Memory issues are common in resource-intensive builds. The solution involves optimizing memory allocation and monitoring.'
    },
    'Network connectivity issues': {
      rootCause: 'Network connectivity problems during build process',
      errorPatterns: ['Connection refused', 'Network unreachable', 'Timeout'],
      immediateActions: [
        'Check network configuration',
        'Add retry logic for network operations',
        'Implement network health checks',
        'Use local mirrors for dependencies'
      ],
      preventionStrategies: [
        'Set up network monitoring',
        'Implement circuit breakers',
        'Use dependency caching',
        'Configure fallback mechanisms'
      ],
      confidence: 'Medium',
      explanation: 'Network issues can be intermittent and environment-specific. The solution focuses on resilience and monitoring.'
    },
    'default': {
      rootCause: `Generic failure in ${jobName} pipeline`,
      errorPatterns: ['Build failed', 'Error in execution'],
      immediateActions: [
        'Review build logs for specific error details',
        'Check recent changes in the repository',
        'Verify environment configuration',
        'Test the build locally if possible'
      ],
      preventionStrategies: [
        'Implement better logging and monitoring',
        'Add pre-build validation steps',
        'Set up automated testing',
        'Create build failure alert system'
      ],
      confidence: 'Medium',
      explanation: 'Generic analysis based on common Jenkins failure patterns. Specific root cause requires detailed investigation.'
    }
  };

  // Find the best matching analysis
  const key = Object.keys(analyses).find(k => 
    failureReason.toLowerCase().includes(k.toLowerCase())
  ) || 'default';

  return analyses[key];
}

// Mock AI fix generation
export function getMockFix(failureReason: string, jobName: string): AIFix {
  const fixes: Record<string, AIFix> = {
    'Test timeout': {
      rootCause: 'Test timeout due to inefficient test configuration and execution',
      confidence: 'High',
      immediateActions: [
        'Increase test timeout configuration',
        'Optimize test performance',
        'Enable parallel test execution'
      ],
      fileChanges: [
        {
          filePath: 'jest.config.js',
          changeType: 'modify',
          description: 'Increase test timeout and add parallel execution',
          content: `module.exports = {
  testTimeout: 900000, // 15 minutes
  maxWorkers: 4,
  verbose: true,
  setupFilesAfterEnv: ['<rootDir>/setupTests.js']
}`
        },
        {
          filePath: 'package.json',
          changeType: 'modify',
          description: 'Update test script with better flags',
          content: `"test": "jest --runInBand --coverage --maxWorkers=4"`
        }
      ],
      pipelineChanges: [
        {
          parameter: 'TEST_TIMEOUT',
          oldValue: '600',
          newValue: '900',
          description: 'Increase test timeout parameter'
        },
        {
          parameter: 'PARALLEL_TESTS',
          oldValue: 'false',
          newValue: 'true',
          description: 'Enable parallel test execution'
        }
      ],
      riskAssessment: {
        level: 'low',
        description: 'Low risk changes that only affect test configuration',
        mitigations: [
          'Changes are backwards compatible',
          'No impact on production code',
          'Can be easily rolled back'
        ]
      }
    },
    'Memory limit exceeded': {
      rootCause: 'Insufficient memory allocation for build process',
      confidence: 'High',
      immediateActions: [
        'Increase JVM heap size',
        'Optimize memory usage in build steps',
        'Add memory monitoring'
      ],
      fileChanges: [
        {
          filePath: 'Jenkinsfile',
          changeType: 'modify',
          description: 'Add JVM memory configuration',
          content: `pipeline {
    agent any
    environment {
        JAVA_OPTS = '-Xmx4g -Xms2g'
    }
    stages {
        stage('Build') {
            steps {
                sh './mvnw clean package -DskipTests'
            }
        }
    }
}`
        }
      ],
      pipelineChanges: [
        {
          parameter: 'JAVA_OPTS',
          oldValue: '-Xmx2g',
          newValue: '-Xmx4g -Xms2g',
          description: 'Increase JVM memory allocation'
        }
      ],
      riskAssessment: {
        level: 'low',
        description: 'Memory configuration changes with minimal risk',
        mitigations: [
          'Monitor memory usage after changes',
          'Have rollback plan ready',
          'Test in staging environment first'
        ]
      }
    },
    'default': {
      rootCause: 'Generic build failure requiring investigation',
      confidence: 'Medium',
      immediateActions: [
        'Review build logs',
        'Check recent changes',
        'Verify environment setup'
      ],
      fileChanges: [
        {
          filePath: 'Jenkinsfile',
          changeType: 'modify',
          description: 'Add better error handling and logging',
          content: `pipeline {
    agent any
    stages {
        stage('Build') {
            steps {
                script {
                    try {
                        sh './build.sh'
                    } catch (Exception e) {
                        echo "Build failed: ${e.getMessage()}"
                        currentBuild.result = 'FAILURE'
                        throw e
                    }
                }
            }
        }
    }
    post {
        always {
            echo 'Build completed with status: ' + currentBuild.result
        }
    }
}`
        }
      ],
      pipelineChanges: [],
      riskAssessment: {
        level: 'medium',
        description: 'Generic fix with moderate risk due to unknown root cause',
        mitigations: [
          'Test in development environment first',
          'Have rollback plan ready',
          'Monitor closely after deployment'
        ]
      }
    }
  };

  const key = Object.keys(fixes).find(k => 
    failureReason.toLowerCase().includes(k.toLowerCase())
  ) || 'default';

  return fixes[key];
}

// Mock knowledge base improvement
export function getMockKnowledgeImprovement(): KnowledgeImprovement {
  return {
    gaps: [
      'Missing automated test timeout optimization',
      'No memory usage monitoring in pipelines',
      'Insufficient network failure handling',
      'Lack of build performance metrics'
    ],
    newSolutions: [
      {
        title: 'Test Timeout Optimization',
        description: 'Automatically adjust test timeouts based on historical data',
        category: 'Performance',
        severity: 'medium',
        problemPatterns: ['Test timeout', 'Slow tests'],
        estimatedFixTime: 120,
        successRate: 85
      },
      {
        title: 'Memory Monitoring Integration',
        description: 'Add memory usage monitoring and alerts to Jenkins pipelines',
        category: 'Monitoring',
        severity: 'high',
        problemPatterns: ['Memory limit exceeded', 'OutOfMemoryError'],
        estimatedFixTime: 90,
        successRate: 90
      }
    ],
    patterns: [
      {
        name: 'Weekend Build Failures',
        description: 'Builds frequently fail on weekends due to maintenance windows',
        category: 'Temporal',
        frequency: 15
      },
      {
        name: 'Large Test Suite Timeouts',
        description: 'Test suites with more than 100 tests frequently timeout',
        category: 'Performance',
        frequency: 25
      }
    ],
    recommendations: [
      'Implement automated performance monitoring',
      'Set up build failure alert system',
      'Create knowledge base for common solutions',
      'Implement predictive failure analysis'
    ],
    automation: [
      'Automated test timeout adjustment',
      'Self-healing build configurations',
      'Automated failure pattern detection',
      'Intelligent retry mechanisms'
    ]
  };
}

// Check if Ollama is available
export async function isOllamaAvailable(baseUrl: string = 'http://localhost:11434'): Promise<boolean> {
  try {
    const response = await fetch(`${baseUrl}/api/tags`, {
      method: 'GET',
      signal: AbortSignal.timeout(5000) // 5 second timeout
    });
    return response.ok;
  } catch (error) {
    return false;
  }
}

// Get AI analysis with fallback
export async function getAIAnalysisWithFallback(
  failureReason: string,
  jobName: string,
  buildNumber: string,
  logs: string[] = [],
  config?: { baseUrl: string; model: string }
): Promise<{ success: boolean; analysis?: AIAnalysis; error?: string; isFallback?: boolean }> {
  const baseUrl = config?.baseUrl || 'http://localhost:11434';
  
  // Check if Ollama is available
  const ollamaAvailable = await isOllamaAvailable(baseUrl);
  
  if (!ollamaAvailable) {
    console.log('Ollama not available, using fallback analysis');
    return {
      success: true,
      analysis: getMockAnalysis(failureReason, jobName),
      isFallback: true
    };
  }

  try {
    // Try to get real AI analysis
    const response = await fetch('/api/ollama', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        action: 'analyze-failure',
        failureReason,
        logs,
        jobName,
        buildNumber,
        config
      })
    });

    const result = await response.json();
    
    if (result.success) {
      return {
        success: true,
        analysis: result.analysis
      };
    } else {
      console.log('AI analysis failed, using fallback:', result.error);
      return {
        success: true,
        analysis: getMockAnalysis(failureReason, jobName),
        isFallback: true
      };
    }
  } catch (error) {
    console.log('Error calling AI analysis, using fallback:', error);
    return {
      success: true,
      analysis: getMockAnalysis(failureReason, jobName),
      isFallback: true
    };
  }
}