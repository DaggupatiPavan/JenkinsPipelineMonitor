import { NextRequest, NextResponse } from 'next/server'

interface OllamaRequest {
  model: string
  prompt: string
  stream?: boolean
  options?: {
    temperature?: number
    top_p?: number
    top_k?: number
    num_predict?: number
  }
}

interface OllamaResponse {
  model: string
  created_at: string
  response: string
  done: boolean
  context?: number[]
  total_duration?: number
  load_duration?: number
  prompt_eval_count?: number
  prompt_eval_duration?: number
  eval_count?: number
  eval_duration?: number
}

// Model-specific timeout configurations
const MODEL_TIMEOUTS: Record<string, number> = {
  'llama3.2': 300000,    // 5 minutes
  'llama3.1': 300000,    // 5 minutes  
  'llama3': 300000,      // 5 minutes
  'mistral': 240000,     // 4 minutes
  'codellama': 240000,   // 4 minutes
  'phi3': 180000,        // 3 minutes
  'gemma': 180000,       // 3 minutes
  'default': 300000      // 5 minutes default
}

// Default Ollama configuration
const DEFAULT_OLLAMA_CONFIG = {
  baseUrl: process.env.OLLAMA_BASE_URL || process.env.NEXT_PUBLIC_OLLAMA_BASE_URL || 'http://localhost:11434',
  model: process.env.OLLAMA_MODEL || process.env.NEXT_PUBLIC_OLLAMA_MODEL || 'llama3.2',
  timeout: 300000 // 300 seconds (5 minutes) - increased timeout for complex AI processing
}

function getModelTimeout(model: string): number {
  // Extract base model name (remove version suffixes like :latest, :7b, etc.)
  const baseModel = model.split(':')[0].toLowerCase()
  return MODEL_TIMEOUTS[baseModel] || MODEL_TIMEOUTS.default
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, ...data } = body

    if (action === 'analyze-failure') {
      return await analyzeFailure(data)
    }

    if (action === 'generate-detailed-fix') {
      return await generateDetailedFix(data)
    }

    if (action === 'generate-solution') {
      return await generateSolution(data)
    }

    if (action === 'improve-knowledge') {
      return await improveKnowledgeBase(data)
    }

    if (action === 'chat') {
      return await chatWithOllama(data)
    }

    if (action === 'test-connection') {
      return await testConnection(data)
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Ollama API error:', error)
    return NextResponse.json(
      { error: 'Failed to process Ollama request' },
      { status: 500 }
    )
  }
}

async function testConnection(config: any) {
  try {
    const baseUrl = config.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    console.log(`Testing Ollama connection to: ${baseUrl}`)
    
    const response = await fetch(`${baseUrl}/api/tags`, {
      method: 'GET',
      signal: AbortSignal.timeout(15000), // 15 second timeout for connection test
    })

    if (response.ok) {
      const models = await response.json()
      console.log(`Ollama connection successful. Found ${models.models?.length || 0} models`)
      return NextResponse.json({
        success: true,
        message: 'Connected to Ollama successfully',
        models: models.models || [],
        config
      })
    } else {
      const errorText = await response.text()
      console.error(`Ollama connection failed: ${response.status} ${response.statusText}`, errorText)
      throw new Error(`Failed to connect: ${response.status} ${response.statusText}`)
    }
  } catch (error) {
    console.error('Ollama connection test failed:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    
    // Provide more helpful error messages
    if (errorMessage.includes('ECONNREFUSED')) {
      return NextResponse.json({
        success: false,
        message: 'Connection refused: Ollama server is not running. Please start Ollama using: ollama serve',
        config,
        suggestion: 'Start Ollama server: ollama serve'
      })
    } else if (errorMessage.includes('timeout')) {
      return NextResponse.json({
        success: false,
        message: 'Connection timeout: Ollama server is not responding. Please check if Ollama is running.',
        config,
        suggestion: 'Check Ollama status: ollama ps'
      })
    } else {
      return NextResponse.json({
        success: false,
        message: `Connection failed: ${errorMessage}`,
        config,
        suggestion: 'Please ensure Ollama is installed and running: ollama serve'
      })
    }
  }
}

async function analyzeFailure(data: any) {
  try {
    const { failureReason, logs, jobName, buildNumber } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    console.log(`Starting AI analysis for job: ${jobName}, build: ${buildNumber}`)
    console.log(`Using Ollama endpoint: ${baseUrl}, model: ${model}`)

    // Create a concise prompt for failure analysis
    const prompt = `Analyze this Jenkins failure:

Job: ${jobName}
Build: ${buildNumber}
Failure: ${failureReason}
Logs: ${logs?.slice(0, 1000).join('\n') || 'No logs'}

Provide JSON response:
{
  "rootCause": "string",
  "errorPatterns": ["string"],
  "immediateActions": ["string"],
  "preventionStrategies": ["string"],
  "confidence": "High|Medium|Low",
  "explanation": "string"
}`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt,
      stream: false,
      options: {
        temperature: 0.3,
        top_p: 0.9,
        num_predict: 300 // Reduced token count for faster response
      }
    }

    const modelTimeout = getModelTimeout(model)
    console.log(`Sending request to Ollama API: ${baseUrl}/api/generate (timeout: ${modelTimeout}ms)`)
    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(modelTimeout),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`Ollama request failed: ${response.status} ${response.statusText}`, errorText)
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    console.log(`Ollama response received, length: ${ollamaResponse.response?.length || 0}`)
    
    try {
      // Try to parse the response as JSON
      const analysis = JSON.parse(ollamaResponse.response)
      console.log('AI analysis completed successfully')
      return NextResponse.json({
        success: true,
        analysis,
        rawResponse: ollamaResponse.response
      })
    } catch (parseError) {
      console.warn('Failed to parse AI response as JSON, returning raw response')
      // If JSON parsing fails, return the raw response
      return NextResponse.json({
        success: true,
        analysis: {
          rootCause: 'Analysis completed but response format was unexpected',
          errorPatterns: [],
          immediateActions: [],
          preventionStrategies: [],
          confidence: 'Medium',
          explanation: ollamaResponse.response
        },
        rawResponse: ollamaResponse.response
      })
    }
  } catch (error) {
    console.error('Failure analysis failed:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    
    // Provide more specific error messages
    if (errorMessage.includes('timeout')) {
      return NextResponse.json({
        success: false,
        error: `AI analysis timeout: The AI model took too long to respond. Please try again or check your Ollama server.`,
        suggestion: 'Try increasing the timeout or using a smaller model'
      })
    } else if (errorMessage.includes('ECONNREFUSED')) {
      return NextResponse.json({
        success: false,
        error: `AI analysis failed: Ollama server is not running. Please start Ollama using: ollama serve`,
        suggestion: 'Start Ollama server and ensure the model is downloaded'
      })
    } else {
      return NextResponse.json({
        success: false,
        error: `Failed to analyze failure: ${errorMessage}`,
        suggestion: 'Please check your Ollama configuration and try again'
      })
    }
  }
}

async function generateDetailedFix(data: any) {
  try {
    const { failureReason, logs, jobName, buildNumber } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    // Create a concise prompt for detailed fix generation
    const prompt = `Generate a fix for this Jenkins failure:

Job: ${jobName}
Build: ${buildNumber}
Failure: ${failureReason}
Logs: ${logs?.slice(0, 1000).join('\n') || 'No logs'}

Provide JSON response:
{
  "rootCause": "string",
  "confidence": "High|Medium|Low",
  "immediateActions": ["string"],
  "fileChanges": [{"filePath": "string", "changeType": "modify|create|delete", "description": "string", "content": "string"}],
  "pipelineChanges": [{"parameter": "string", "oldValue": "string", "newValue": "string", "description": "string"}],
  "riskAssessment": {"level": "low|medium|high", "description": "string", "mitigations": ["string"]}
}`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt,
      stream: false,
      options: {
        temperature: 0.3,
        top_p: 0.9,
        num_predict: 400 // Reduced token count for faster response
      }
    }

    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(getModelTimeout(model)),
    })

    if (!response.ok) {
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    
    try {
      // Try to parse the response as JSON
      const analysis = JSON.parse(ollamaResponse.response)
      return NextResponse.json({
        success: true,
        analysis,
        rawResponse: ollamaResponse.response
      })
    } catch (parseError) {
      // If JSON parsing fails, create a structured response from the raw text
      return NextResponse.json({
        success: true,
        analysis: {
          rootCause: 'Analysis completed but response format was unexpected',
          confidence: 'Medium',
          immediateActions: ['Review the raw analysis for detailed recommendations'],
          fileChanges: [],
          pipelineChanges: [],
          riskAssessment: {
            level: 'medium',
            description: 'Unable to parse structured risk assessment from AI response',
            mitigations: ['Manual review required']
          }
        },
        rawResponse: ollamaResponse.response
      })
    }
  } catch (error) {
    console.error('Detailed fix generation failed:', error)
    return NextResponse.json({
      success: false,
      error: `Failed to generate detailed fix: ${error instanceof Error ? error.message : 'Unknown error'}`
    })
  }
}

async function generateSolution(data: any) {
  try {
    const { problem, context, existingSolutions } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    const prompt = `Generate a solution for this Jenkins problem:

Problem: ${problem}
Context: ${context}
Existing Solutions: ${existingSolutions?.map((s: any) => `${s.title}: ${s.description}`).join('; ') || 'None'}

Provide JSON response:
{
  "title": "string",
  "description": "string",
  "rootCauses": ["string"],
  "solutions": [{"title": "string", "description": "string", "command": "string", "code": "string", "verification": "string", "rollback": "string", "risk": "low|medium|high", "required": true}],
  "prevention": [{"title": "string", "description": "string", "implementation": "string", "monitoring": "string"}],
  "estimatedFixTime": number,
  "successRate": number,
  "tags": ["string"]
}`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt,
      stream: false,
      options: {
        temperature: 0.4,
        top_p: 0.9,
        num_predict: 400 // Reduced token count for faster response
      }
    }

    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(getModelTimeout(model)),
    })

    if (!response.ok) {
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    
    try {
      const solution = JSON.parse(ollamaResponse.response)
      return NextResponse.json({
        success: true,
        solution,
        rawResponse: ollamaResponse.response
      })
    } catch (parseError) {
      return NextResponse.json({
        success: true,
        solution: {
          title: 'AI-Generated Solution',
          description: ollamaResponse.response,
          rootCauses: [],
          solutions: [],
          prevention: [],
          estimatedFixTime: 60,
          successRate: 75,
          tags: ['ai-generated']
        },
        rawResponse: ollamaResponse.response
      })
    }
  } catch (error) {
    console.error('Solution generation failed:', error)
    return NextResponse.json({
      success: false,
      error: `Failed to generate solution: ${error instanceof Error ? error.message : 'Unknown error'}`
    })
  }
}

async function improveKnowledgeBase(data: any) {
  try {
    const { failures, solutions, patterns } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    console.log('Starting knowledge base improvement analysis')
    console.log(`Using Ollama endpoint: ${baseUrl}, model: ${model}`)

    const prompt = `Analyze this Jenkins data and suggest improvements:

Failures: ${failures?.map((f: any) => `${f.reason}: ${f.count} occurrences`).join('; ') || 'No data'}
Solutions: ${solutions?.map((s: any) => `${s.title}: ${s.description} (${s.successRate}%)`).join('; ') || 'No data'}
Patterns: ${patterns?.map((p: any) => `${p.name}: ${p.description} (${p.frequency})`).join('; ') || 'No data'}

Provide JSON response:
{
  "gaps": ["string"],
  "newSolutions": [{"title": "string", "description": "string", "category": "string", "severity": "low|medium|high|critical", "problemPatterns": ["string"], "estimatedFixTime": number, "successRate": number}],
  "patterns": [{"name": "string", "description": "string", "category": "string", "frequency": number}],
  "recommendations": ["string"],
  "automation": ["string"]
}`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt,
      stream: false,
      options: {
        temperature: 0.5,
        top_p: 0.9,
        num_predict: 400 // Reduced token count for faster response
      }
    }

    const modelTimeout = getModelTimeout(model)
    console.log(`Sending knowledge base improvement request to Ollama API: ${baseUrl}/api/generate (timeout: ${modelTimeout}ms)`)
    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(modelTimeout),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`Ollama request failed: ${response.status} ${response.statusText}`, errorText)
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    console.log(`Knowledge base improvement response received, length: ${ollamaResponse.response?.length || 0}`)
    
    try {
      const improvements = JSON.parse(ollamaResponse.response)
      console.log('Knowledge base improvement completed successfully')
      return NextResponse.json({
        success: true,
        improvements,
        rawResponse: ollamaResponse.response
      })
    } catch (parseError) {
      console.warn('Failed to parse knowledge base improvement as JSON, returning raw response')
      return NextResponse.json({
        success: true,
        improvements: {
          gaps: [ollamaResponse.response],
          newSolutions: [],
          patterns: [],
          recommendations: [],
          automation: []
        },
        rawResponse: ollamaResponse.response
      })
    }
  } catch (error) {
    console.error('Knowledge base improvement failed:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    
    // Provide more specific error messages
    if (errorMessage.includes('timeout')) {
      return NextResponse.json({
        success: false,
        error: `Failed to improve knowledge base: The operation was aborted due to timeout. The AI model took too long to respond.`,
        suggestion: 'Try increasing the timeout or using a smaller model like "llama3.2" instead of larger models.'
      })
    } else if (errorMessage.includes('ECONNREFUSED')) {
      return NextResponse.json({
        success: false,
        error: `Failed to improve knowledge base: Ollama server is not running. Please start Ollama using: ollama serve`,
        suggestion: 'Start Ollama server and ensure the model is downloaded: ollama pull llama3.2'
      })
    } else if (errorMessage.includes('model not found')) {
      return NextResponse.json({
        success: false,
        error: `Failed to improve knowledge base: Model not found. Please download the model first.`,
        suggestion: `Download the model: ollama pull ${data.config?.model || 'llama3.2'}`
      })
    } else {
      return NextResponse.json({
        success: false,
        error: `Failed to improve knowledge base: ${errorMessage}`,
        suggestion: 'Please check your Ollama configuration and ensure the model is available'
      })
    }
  }
}

async function chatWithOllama(data: any) {
  try {
    const { message, context, history } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    const systemPrompt = `You are an expert Jenkins pipeline assistant with deep knowledge of DevOps, CI/CD, and troubleshooting. You help users resolve pipeline issues, optimize builds, and implement best practices.

Context: ${context || 'Jenkins Pipeline Monitor'}

Previous conversation:
${history?.map((h: any) => `${h.role}: ${h.message}`).join('\n') || 'No previous conversation'}

User: ${message}

Please provide a helpful, accurate, and actionable response. If you need to suggest commands or code, format them clearly. If you're not sure about something, acknowledge the uncertainty and suggest ways to verify the information.`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt: systemPrompt,
      stream: false,
      options: {
        temperature: 0.7,
        top_p: 0.9,
        num_predict: 400
      }
    }

    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(getModelTimeout(model)),
    })

    if (!response.ok) {
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    
    return NextResponse.json({
      success: true,
      response: ollamaResponse.response,
      model: ollamaResponse.model,
      timestamp: ollamaResponse.created_at
    })
  } catch (error) {
    console.error('Chat failed:', error)
    return NextResponse.json({
      success: false,
      error: `Failed to chat: ${error instanceof Error ? error.message : 'Unknown error'}`
    })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get('action')

    if (action === 'models') {
      const baseUrl = searchParams.get('baseUrl') || DEFAULT_OLLAMA_CONFIG.baseUrl
      const response = await fetch(`${baseUrl}/api/tags`, {
        signal: AbortSignal.timeout(10000),
      })

      if (response.ok) {
        const data = await response.json()
        return NextResponse.json({
          success: true,
          models: data.models || []
        })
      } else {
        throw new Error(`Failed to fetch models: ${response.status} ${response.statusText}`)
      }
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Ollama GET request failed:', error)
    return NextResponse.json(
      { error: 'Failed to process Ollama request' },
      { status: 500 }
    )
  }
}