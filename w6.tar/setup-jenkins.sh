#!/bin/bash

# Jenkins Setup Script for Pipeline Monitor
# This script helps you set up Jenkins connection

echo "🚀 Jenkins Pipeline Monitor Setup"
echo "=================================="

# Check if .env.local exists
if [ ! -f ".env.local" ]; then
    echo "📝 Creating .env.local file..."
    cat > .env.local << EOF
# Jenkins Configuration - REPLACE WITH YOUR ACTUAL VALUES
NEXT_PUBLIC_JENKINS_URL=http://20.121.40.237:8080
NEXT_PUBLIC_JENKINS_USERNAME=admin
NEXT_PUBLIC_JENKINS_API_TOKEN=REPLACE_WITH_YOUR_JENKINS_API_TOKEN

# Ollama Configuration
NEXT_PUBLIC_OLLAMA_BASE_URL=http://localhost:11434
NEXT_PUBLIC_OLLAMA_MODEL=llama3.2

# Database Configuration
DATABASE_URL=file:/home/z/my-project/db/custom.db

# Next.js Configuration
NEXTAUTH_SECRET=your-nextauth-secret-here
NEXTAUTH_URL=http://localhost:3000

# Application Configuration
NODE_ENV=development
PORT=3000
EOF
    echo "✅ Created .env.local file"
else
    echo "ℹ️  .env.local file already exists"
fi

echo ""
echo "📋 Next Steps:"
echo "1. Get your Jenkins API token:"
echo "   - Open http://20.121.40.237:8080 in your browser"
echo "   - Log in with your Jenkins credentials"
echo "   - Click on your username in the top-right corner"
echo "   - Click 'Configure' in the left sidebar"
echo "   - Scroll down to 'API Token' section"
echo "   - Click 'Add new Token' and enter a name (e.g., 'pipeline-monitor')"
echo "   - Click 'Generate' and copy the token immediately"
echo ""
echo "2. Update your configuration:"
echo "   - Edit .env.local file"
echo "   - Replace 'REPLACE_WITH_YOUR_JENKINS_API_TOKEN' with your actual token"
echo ""
echo "3. Test your connection:"
echo "   - Update debug-jenkins.js with your API token"
echo "   - Run: node debug-jenkins.js"
echo ""
echo "4. Start the application:"
echo "   - Run: npm run dev"
echo "   - Open http://localhost:3000 in your browser"
echo ""
echo "📚 Documentation:"
echo "   - JENKINS_SETUP.md: Detailed setup instructions"
echo "   - JENKINS_TROUBLESHOOTING.md: Common issues and solutions"
echo ""
echo "🔧 Need help? Check the documentation files or run the debug script!"