import { NextRequest, NextResponse } from 'next/server'
import { jenkinsService } from '@/lib/jenkins'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const jobName = searchParams.get('jobName')
    const buildNumber = searchParams.get('buildNumber')
    const jenkinsUrl = searchParams.get('url')
    const username = searchParams.get('username')
    const apiToken = searchParams.get('apiToken')

    if (!jobName || !jenkinsUrl || !username || !apiToken) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      )
    }

    // Set configuration for this request
    jenkinsService.setConfig({
      url: jenkinsUrl,
      username,
      apiToken
    })

    let actualBuildNumber = buildNumber
    
    if (!actualBuildNumber) {
      // Get latest build number if not provided
      const jobs = await jenkinsService.getJobs()
      const job = jobs.find(j => j.name === jobName)
      
      if (job && job.lastBuild) {
        actualBuildNumber = String(job.lastBuild.number)
      }
    }

    if (!actualBuildNumber) {
      return NextResponse.json(
        { error: 'No build number found for job: ' + jobName },
        { status: 404 }
      )
    }

    // Get the raw logs
    const rawLogs = await jenkinsService.getBuildLog(jobName, parseInt(actualBuildNumber))
    
    // Create download response
    const filename = `${jobName}-${actualBuildNumber}-logs.txt`
    
    return new NextResponse(rawLogs, {
      headers: {
        'Content-Type': 'text/plain',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': rawLogs.length.toString()
      }
    })
  } catch (error) {
    console.error('Download logs error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to download logs',
        details: error instanceof Error ? error.message : String(error)
      },
      { status: 500 }
    )
  }
}