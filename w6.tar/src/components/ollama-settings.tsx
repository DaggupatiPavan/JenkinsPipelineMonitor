'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  Bot, 
  Settings, 
  TestTube, 
  Brain, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  RefreshCw,
  Save,
  Wifi,
  WifiOff
} from 'lucide-react'

interface OllamaConfig {
  baseUrl: string
  model: string
  enabled: boolean
  autoAnalyze: boolean
  temperature: number
  maxTokens: number
  timeout: number
}

interface OllamaModel {
  name: string
  modified_at: string
  size: number
}

interface OllamaSettingsProps {
  onConfigChange?: (config: OllamaConfig) => void
  onClose?: () => void
}

export function OllamaSettings({ onConfigChange, onClose }: OllamaSettingsProps) {
  const [config, setConfig] = useState<OllamaConfig>({
    baseUrl: process.env.NEXT_PUBLIC_OLLAMA_BASE_URL || 'http://localhost:11434',
    model: process.env.NEXT_PUBLIC_OLLAMA_MODEL || 'llama3.2',
    enabled: false,
    autoAnalyze: true,
    temperature: 0.7,
    maxTokens: 1000,
    timeout: 120000 // Updated to match API route timeout
  })
  
  const [models, setModels] = useState<OllamaModel[]>([])
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected')
  const [connectionError, setConnectionError] = useState('')
  const [testingConnection, setTestingConnection] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
    // Load saved config from localStorage
    const savedConfig = localStorage.getItem('ollamaConfig')
    if (savedConfig) {
      try {
        const parsed = JSON.parse(savedConfig)
        setConfig(prev => ({ ...prev, ...parsed }))
      } catch (error) {
        console.error('Failed to load Ollama config:', error)
      }
    }
  }, [])

  useEffect(() => {
    if (config.enabled && isMounted) {
      testConnection()
    }
  }, [config.baseUrl, config.enabled, isMounted])

  const testConnection = async () => {
    setTestingConnection(true)
    setConnectionStatus('connecting')
    setConnectionError('')

    try {
      const response = await fetch('/api/ollama', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'test-connection',
          config: {
            baseUrl: config.baseUrl,
            model: config.model
          }
        })
      })

      const result = await response.json()

      if (result.success) {
        setConnectionStatus('connected')
        setModels(result.models || [])
        // Update model list and ensure current model is available
        if (result.models && result.models.length > 0) {
          const modelNames = result.models.map((m: OllamaModel) => m.name)
          if (!modelNames.includes(config.model)) {
            setConfig(prev => ({ ...prev, model: modelNames[0] }))
          }
        }
      } else {
        setConnectionStatus('error')
        setConnectionError(result.message || 'Connection failed')
      }
    } catch (error) {
      console.error('Connection test failed:', error)
      setConnectionStatus('error')
      setConnectionError('Network error while connecting to Ollama')
    } finally {
      setTestingConnection(false)
    }
  }

  const handleSaveConfig = () => {
    // Save to localStorage
    localStorage.setItem('ollamaConfig', JSON.stringify(config))
    
    // Notify parent component
    if (onConfigChange) {
      onConfigChange(config)
    }
    
    // Show success message
    alert('Ollama configuration saved successfully!')
  }

  const handleResetConfig = () => {
    const defaultConfig: OllamaConfig = {
      baseUrl: 'http://localhost:11434',
      model: 'llama3.2',
      enabled: false,
      autoAnalyze: true,
      temperature: 0.7,
      maxTokens: 1000,
      timeout: 120000 // Updated default timeout
    }
    setConfig(defaultConfig)
    localStorage.removeItem('ollamaConfig')
    setConnectionStatus('disconnected')
    setModels([])
  }

  const getConnectionIcon = () => {
    switch (connectionStatus) {
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'connecting':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <WifiOff className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'bg-green-100 text-green-800'
      case 'connecting':
        return 'bg-blue-100 text-blue-800'
      case 'error':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (!isMounted) {
    return <div>Loading settings...</div>
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            Ollama AI Integration
          </CardTitle>
          <CardDescription>
            Configure Ollama for AI-powered Jenkins issue resolution and knowledge base enhancement
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Label htmlFor="ollama-enabled">Enable Ollama Integration</Label>
              <Switch
                id="ollama-enabled"
                checked={config.enabled}
                onCheckedChange={(checked) => setConfig(prev => ({ ...prev, enabled: checked }))}
              />
            </div>
            <div className="flex items-center gap-2">
              {getConnectionIcon()}
              <Badge className={getStatusColor()}>
                {connectionStatus === 'connected' && 'Connected'}
                {connectionStatus === 'connecting' && 'Connecting...'}
                {connectionStatus === 'error' && 'Connection Failed'}
                {connectionStatus === 'disconnected' && 'Not Connected'}
              </Badge>
            </div>
          </div>

          {connectionError && (
            <Alert className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Connection Error:</strong> {connectionError}
                {connectionError.includes('suggestion') && (
                  <div className="mt-2 p-2 bg-blue-50 rounded text-sm">
                    <strong>Suggestion:</strong> {connectionError.split('suggestion: ')[1]}
                  </div>
                )}
                <div className="mt-2 text-sm">
                  <strong>Troubleshooting:</strong>
                  <ul className="list-disc list-inside mt-1">
                    <li>Ensure Ollama is running on the specified URL</li>
                    <li>Check if the model is downloaded: <code>ollama pull {config.model}</code></li>
                    <li>Verify network connectivity and firewall settings</li>
                    <li>Check Ollama logs: <code>ollama ps</code></li>
                    <li>Start Ollama server: <code>ollama serve</code></li>
                  </ul>
                </div>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="connection" className="space-y-4">
        <TabsList>
          <TabsTrigger value="connection">Connection</TabsTrigger>
          <TabsTrigger value="models">Models</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
          <TabsTrigger value="features">AI Features</TabsTrigger>
        </TabsList>

        <TabsContent value="connection" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Connection Settings</CardTitle>
              <CardDescription>
                Configure your Ollama server connection
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="baseUrl">Ollama Server URL</Label>
                  <Input
                    id="baseUrl"
                    placeholder="http://localhost:11434"
                    value={config.baseUrl}
                    onChange={(e) => setConfig(prev => ({ ...prev, baseUrl: e.target.value }))}
                    disabled={!config.enabled}
                  />
                  <p className="text-xs text-muted-foreground">
                    Default: http://localhost:11434
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="timeout">Connection Timeout (ms)</Label>
                  <Input
                    id="timeout"
                    type="number"
                    min="30000"
                    max="300000"
                    step="10000"
                    value={config.timeout}
                    onChange={(e) => setConfig(prev => ({ ...prev, timeout: parseInt(e.target.value) }))}
                    disabled={!config.enabled}
                  />
                  <p className="text-xs text-muted-foreground">
                    Default: 120000ms (2 minutes). Increase for complex AI analysis tasks.
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button 
                  onClick={testConnection} 
                  disabled={!config.enabled || testingConnection}
                  variant="outline"
                >
                  <TestTube className="mr-2 h-4 w-4" />
                  {testingConnection ? 'Testing...' : 'Test Connection'}
                </Button>
                
                {connectionStatus === 'connected' && (
                  <Badge variant="outline" className="text-green-600">
                    <CheckCircle className="mr-1 h-3 w-3" />
                    {models.length} models available
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="models" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Model Selection</CardTitle>
              <CardDescription>
                Choose the AI model for analysis and recommendations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="model">AI Model</Label>
                <Select 
                  value={config.model} 
                  onValueChange={(value) => setConfig(prev => ({ ...prev, model: value }))}
                  disabled={!config.enabled || connectionStatus !== 'connected'}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a model" />
                  </SelectTrigger>
                  <SelectContent>
                    {models.length > 0 ? (
                      models.map((model) => (
                        <SelectItem key={model.name} value={model.name}>
                          {model.name}
                          <span className="text-xs text-muted-foreground ml-2">
                            ({Math.round(model.size / 1024 / 1024 / 1024)}GB)
                          </span>
                        </SelectItem>
                      ))
                    ) : (
                      <>
                        <SelectItem value="llama3.2">llama3.2 (default)</SelectItem>
                        <SelectItem value="llama3.1">llama3.1</SelectItem>
                        <SelectItem value="mistral">mistral</SelectItem>
                        <SelectItem value="codellama">codellama</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Recommended: llama3.2 for general analysis, codellama for code-specific issues
                </p>
              </div>

              {models.length > 0 && (
                <div className="space-y-2">
                  <Label>Available Models</Label>
                  <div className="grid gap-2 max-h-40 overflow-y-auto">
                    {models.map((model) => (
                      <div key={model.name} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <span className="font-medium">{model.name}</span>
                          <span className="text-xs text-muted-foreground ml-2">
                            {Math.round(model.size / 1024 / 1024 / 1024)}GB
                          </span>
                        </div>
                        {model.name === config.model && (
                          <Badge variant="secondary">Active</Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Advanced Settings</CardTitle>
              <CardDescription>
                Fine-tune AI behavior and performance
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="temperature">Temperature ({config.temperature})</Label>
                  <Input
                    id="temperature"
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={config.temperature}
                    onChange={(e) => setConfig(prev => ({ ...prev, temperature: parseFloat(e.target.value) }))}
                    disabled={!config.enabled}
                  />
                  <p className="text-xs text-muted-foreground">
                    Lower = more focused, Higher = more creative
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="maxTokens">Max Tokens</Label>
                  <Input
                    id="maxTokens"
                    type="number"
                    min="100"
                    max="4000"
                    value={config.maxTokens}
                    onChange={(e) => setConfig(prev => ({ ...prev, maxTokens: parseInt(e.target.value) }))}
                    disabled={!config.enabled}
                  />
                  <p className="text-xs text-muted-foreground">
                    Maximum response length
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="features" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI Features</CardTitle>
              <CardDescription>
                Configure which AI-powered features to enable
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Auto-Analyze Failures</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically analyze pipeline failures using AI
                  </p>
                </div>
                <Switch
                  checked={config.autoAnalyze}
                  onCheckedChange={(checked) => setConfig(prev => ({ ...prev, autoAnalyze: checked }))}
                  disabled={!config.enabled}
                />
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-medium">Available AI Features:</h4>
                <div className="grid gap-3">
                  <div className="flex items-start gap-3 p-3 border rounded">
                    <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
                    <div>
                      <h5 className="font-medium">Failure Analysis</h5>
                      <p className="text-sm text-muted-foreground">
                        AI-powered root cause analysis and recommendations
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 p-3 border rounded">
                    <Settings className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h5 className="font-medium">Solution Generation</h5>
                      <p className="text-sm text-muted-foreground">
                        Generate custom solutions based on failure patterns
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 p-3 border rounded">
                    <Bot className="h-5 w-5 text-purple-500 mt-0.5" />
                    <div>
                      <h5 className="font-medium">Knowledge Base Enhancement</h5>
                      <p className="text-sm text-muted-foreground">
                        Improve knowledge base with AI-generated insights
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-between items-center">
        <Button variant="outline" onClick={handleResetConfig}>
          Reset to Defaults
        </Button>
        <div className="flex gap-2">
          {onClose && (
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
          )}
          <Button onClick={handleSaveConfig}>
            <Save className="mr-2 h-4 w-4" />
            Save Configuration
          </Button>
        </div>
      </div>
    </div>
  )
}