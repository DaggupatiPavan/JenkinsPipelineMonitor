#!/usr/bin/env node

// Test script for Jenkins API endpoints
const fetch = require('node-fetch');

const JENKINS_CONFIG = {
  url: 'http://20.121.40.237:8080',
  username: 'admin',
  apiToken: '115219a84ac43df5537ed94c7abad9fd55'
};

async function testBuildAPI() {
  try {
    console.log('Testing build API...');
    
    const response = await fetch('http://localhost:3000/api/jenkins/build', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        jobName: 'test',
        parameters: {
          DEPLOY_ENV: 'dev',
          RUN_SECURITY_SCANS: 'true',
          APP_NAME: 'complex-java-app',
          DOCKER_TAG: 'latest'
        }
      })
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers));
    
    const text = await response.text();
    console.log('Response body:', text);
    
  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

async function testLogsAPI() {
  try {
    console.log('\nTesting logs API...');
    
    const response = await fetch('http://localhost:3000/api/jenkins/logs', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        jobName: 'test'
      })
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers));
    
    const text = await response.text();
    console.log('Response body:', text);
    
  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

async function testStopAPI() {
  try {
    console.log('\nTesting stop API...');
    
    const response = await fetch('http://localhost:3000/api/jenkins/stop', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        jobName: 'test',
        buildNumber: 1
      })
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers));
    
    const text = await response.text();
    console.log('Response body:', text);
    
  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

// Run tests
testBuildAPI()
  .then(() => testLogsAPI())
  .then(() => testStopAPI())
  .then(() => console.log('\nAll tests completed!'))
  .catch(console.error);