'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { CheckCircle, AlertTriangle, FileText, Settings, GitBranch, Zap, Brain } from 'lucide-react'

interface AIAnalysis {
  rootCause: string
  confidence: string
  immediateActions: string[]
  fileChanges: Array<{
    filePath: string
    changeType: 'modify' | 'create' | 'delete'
    description: string
    content?: string
  }>
  pipelineChanges: Array<{
    parameter: string
    oldValue: string
    newValue: string
    description: string
  }>
  riskAssessment: {
    level: 'low' | 'medium' | 'high'
    description: string
    mitigations: string[]
  }
}

interface AIFixPreviewProps {
  isOpen: boolean
  onClose: () => void
  pipelineName: string
  analysis: AIAnalysis
  onConfirm: () => void
  onReject: () => void
}

export function AIFixPreview({ 
  isOpen, 
  onClose, 
  pipelineName, 
  analysis, 
  onConfirm, 
  onReject 
}: AIFixPreviewProps) {
  const [userInput, setUserInput] = useState('')
  const [showDetails, setShowDetails] = useState(false)

  const handleConfirm = () => {
    if (userInput.toLowerCase().trim() === 'yes') {
      onConfirm()
      onClose()
    } else {
      alert('Please type "yes" to confirm the changes')
    }
  }

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800'
      case 'medium': return 'bg-yellow-100 text-yellow-800'
      case 'high': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getChangeTypeColor = (type: string) => {
    switch (type) {
      case 'modify': return 'bg-blue-100 text-blue-800'
      case 'create': return 'bg-green-100 text-green-800'
      case 'delete': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-blue-500" />
            AI Quick Fix Preview - {pipelineName}
          </DialogTitle>
          <DialogDescription>
            Review the AI-proposed changes before applying them to your pipeline
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="space-y-6">
            {/* Analysis Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  Analysis Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2">Root Cause</h4>
                  <p className="text-sm text-muted-foreground">{analysis.rootCause}</p>
                </div>
                <div className="flex items-center gap-2">
                  <h4 className="font-semibold text-sm">Confidence:</h4>
                  <Badge variant="outline">{analysis.confidence}</Badge>
                </div>
                <div>
                  <h4 className="font-semibold text-sm mb-2">Immediate Actions</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {analysis.immediateActions.map((action, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                        {action}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Risk Assessment */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  Risk Assessment
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <h4 className="font-semibold text-sm">Risk Level:</h4>
                  <Badge className={getRiskColor(analysis.riskAssessment.level)}>
                    {analysis.riskAssessment.level.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{analysis.riskAssessment.description}</p>
                <div>
                  <h4 className="font-semibold text-sm mb-2">Mitigations</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {analysis.riskAssessment.mitigations.map((mitigation, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle className="h-3 w-3 text-blue-500 mt-0.5 flex-shrink-0" />
                        {mitigation}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* File Changes */}
            {analysis.fileChanges.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    File Changes ({analysis.fileChanges.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analysis.fileChanges.map((change, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-mono text-sm">{change.filePath}</h4>
                        <Badge className={getChangeTypeColor(change.changeType)}>
                          {change.changeType.toUpperCase()}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{change.description}</p>
                      {change.content && (
                        <details className="mt-2">
                          <summary className="text-xs text-blue-600 cursor-pointer hover:underline">
                            Show content preview
                          </summary>
                          <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-x-auto">
                            {change.content}
                          </pre>
                        </details>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Pipeline Configuration Changes */}
            {analysis.pipelineChanges.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-4 w-4" />
                    Pipeline Configuration Changes ({analysis.pipelineChanges.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analysis.pipelineChanges.map((change, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-mono text-sm">{change.parameter}</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">{change.description}</p>
                      <div className="grid grid-cols-2 gap-4 text-xs">
                        <div>
                          <span className="text-red-600">Old:</span>
                          <code className="ml-1 bg-red-50 p-1 rounded">{change.oldValue}</code>
                        </div>
                        <div>
                          <span className="text-green-600">New:</span>
                          <code className="ml-1 bg-green-50 p-1 rounded">{change.newValue}</code>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Additional Details Toggle */}
            <Button
              variant="outline"
              onClick={() => setShowDetails(!showDetails)}
              className="w-full"
            >
              {showDetails ? 'Hide' : 'Show'} Technical Details
            </Button>

            {showDetails && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Technical Implementation:</strong> The AI will trigger a new Jenkins build 
                  with the parameters and modifications shown above. The changes will be applied 
                  automatically during the build process.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </ScrollArea>

        {/* Confirmation Section */}
        <div className="border-t pt-4 space-y-4">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Warning:</strong> These changes will be applied to your pipeline. 
              Please review carefully before proceeding.
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <label htmlFor="confirmation" className="text-sm font-medium">
              Type "yes" to confirm these changes:
            </label>
            <input
              id="confirmation"
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Type 'yes' to confirm"
              className="w-full px-3 py-2 border border-input bg-background text-sm rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onReject}>
              Cancel
            </Button>
            <Button 
              onClick={handleConfirm}
              disabled={userInput.toLowerCase().trim() !== 'yes'}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Apply Changes
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}