import { NextRequest, NextResponse } from 'next/server'

interface OllamaRequest {
  model: string
  prompt: string
  stream?: boolean
  options?: {
    temperature?: number
    top_p?: number
    top_k?: number
    num_predict?: number
  }
}

interface OllamaResponse {
  model: string
  created_at: string
  response: string
  done: boolean
  context?: number[]
  total_duration?: number
  load_duration?: number
  prompt_eval_count?: number
  prompt_eval_duration?: number
  eval_count?: number
  eval_duration?: number
}

// Default Ollama configuration
const DEFAULT_OLLAMA_CONFIG = {
  baseUrl: process.env.OLLAMA_BASE_URL || 'http://localhost:11434',
  model: process.env.OLLAMA_MODEL || 'llama3.2',
  timeout: 30000 // 30 seconds
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, ...data } = body

    if (action === 'analyze-failure') {
      return await analyzeFailure(data)
    }

    if (action === 'generate-detailed-fix') {
      return await generateDetailedFix(data)
    }

    if (action === 'generate-solution') {
      return await generateSolution(data)
    }

    if (action === 'improve-knowledge') {
      return await improveKnowledgeBase(data)
    }

    if (action === 'chat') {
      return await chatWithOllama(data)
    }

    if (action === 'test-connection') {
      return await testConnection(data)
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Ollama API error:', error)
    return NextResponse.json(
      { error: 'Failed to process Ollama request' },
      { status: 500 }
    )
  }
}

async function testConnection(config: any) {
  try {
    const baseUrl = config.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const response = await fetch(`${baseUrl}/api/tags`, {
      method: 'GET',
      signal: AbortSignal.timeout(10000),
    })

    if (response.ok) {
      const models = await response.json()
      return NextResponse.json({
        success: true,
        message: 'Connected to Ollama successfully',
        models: models.models || [],
        config
      })
    } else {
      throw new Error(`Failed to connect: ${response.status} ${response.statusText}`)
    }
  } catch (error) {
    console.error('Ollama connection test failed:', error)
    return NextResponse.json({
      success: false,
      message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      config
    })
  }
}

async function analyzeFailure(data: any) {
  try {
    const { failureReason, logs, jobName, buildNumber } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    // Create a comprehensive prompt for failure analysis
    const prompt = `You are an expert Jenkins pipeline troubleshooting assistant. Analyze the following failure and provide detailed insights:

Job: ${jobName}
Build: ${buildNumber}
Failure Reason: ${failureReason}

Relevant Logs:
${logs?.slice(0, 2000).join('\n') || 'No logs available'}

Please provide:
1. Root cause analysis
2. Specific error patterns identified
3. Recommended immediate actions
4. Long-term prevention strategies
5. Confidence level (High/Medium/Low)

Format your response as JSON with the following structure:
{
  "rootCause": "string",
  "errorPatterns": ["string"],
  "immediateActions": ["string"],
  "preventionStrategies": ["string"],
  "confidence": "High|Medium|Low",
  "explanation": "string"
}`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt,
      stream: false,
      options: {
        temperature: 0.3,
        top_p: 0.9,
        num_predict: 500
      }
    }

    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(DEFAULT_OLLAMA_CONFIG.timeout),
    })

    if (!response.ok) {
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    
    try {
      // Try to parse the response as JSON
      const analysis = JSON.parse(ollamaResponse.response)
      return NextResponse.json({
        success: true,
        analysis,
        rawResponse: ollamaResponse.response
      })
    } catch (parseError) {
      // If JSON parsing fails, return the raw response
      return NextResponse.json({
        success: true,
        analysis: {
          rootCause: 'Analysis completed but response format was unexpected',
          errorPatterns: [],
          immediateActions: [],
          preventionStrategies: [],
          confidence: 'Medium',
          explanation: ollamaResponse.response
        },
        rawResponse: ollamaResponse.response
      })
    }
  } catch (error) {
    console.error('Failure analysis failed:', error)
    return NextResponse.json({
      success: false,
      error: `Failed to analyze failure: ${error instanceof Error ? error.message : 'Unknown error'}`
    })
  }
}

async function generateDetailedFix(data: any) {
  try {
    const { failureReason, logs, jobName, buildNumber } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    // Create a comprehensive prompt for detailed fix generation
    const prompt = `You are an expert Jenkins pipeline troubleshooting assistant. Analyze the following failure and generate a detailed fix plan with specific file changes and pipeline modifications:

Job: ${jobName}
Build: ${buildNumber}
Failure Reason: ${failureReason}

Relevant Logs:
${logs?.slice(0, 2000).join('\n') || 'No logs available'}

Please provide a comprehensive analysis and fix plan with the following structure:
1. Root cause analysis
2. Confidence level (High/Medium/Low)
3. Immediate actions to resolve the issue
4. Specific file changes needed (with file paths, change types, and content)
5. Pipeline parameter modifications needed
6. Risk assessment with level, description, and mitigations

Format your response as JSON with the following structure:
{
  "rootCause": "string",
  "confidence": "High|Medium|Low",
  "immediateActions": ["string"],
  "fileChanges": [
    {
      "filePath": "string",
      "changeType": "modify|create|delete",
      "description": "string",
      "content": "string (optional code snippet)"
    }
  ],
  "pipelineChanges": [
    {
      "parameter": "string",
      "oldValue": "string",
      "newValue": "string",
      "description": "string"
    }
  ],
  "riskAssessment": {
    "level": "low|medium|high",
    "description": "string",
    "mitigations": ["string"]
  }
}

Provide realistic and actionable changes based on common Jenkins pipeline issues and best practices.`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt,
      stream: false,
      options: {
        temperature: 0.3,
        top_p: 0.9,
        num_predict: 800
      }
    }

    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(DEFAULT_OLLAMA_CONFIG.timeout),
    })

    if (!response.ok) {
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    
    try {
      // Try to parse the response as JSON
      const analysis = JSON.parse(ollamaResponse.response)
      return NextResponse.json({
        success: true,
        analysis,
        rawResponse: ollamaResponse.response
      })
    } catch (parseError) {
      // If JSON parsing fails, create a structured response from the raw text
      return NextResponse.json({
        success: true,
        analysis: {
          rootCause: 'Analysis completed but response format was unexpected',
          confidence: 'Medium',
          immediateActions: ['Review the raw analysis for detailed recommendations'],
          fileChanges: [],
          pipelineChanges: [],
          riskAssessment: {
            level: 'medium',
            description: 'Unable to parse structured risk assessment from AI response',
            mitigations: ['Manual review required']
          }
        },
        rawResponse: ollamaResponse.response
      })
    }
  } catch (error) {
    console.error('Detailed fix generation failed:', error)
    return NextResponse.json({
      success: false,
      error: `Failed to generate detailed fix: ${error instanceof Error ? error.message : 'Unknown error'}`
    })
  }
}

async function generateSolution(data: any) {
  try {
    const { problem, context, existingSolutions } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    const prompt = `You are an expert DevOps engineer specializing in Jenkins pipeline optimization. Generate a comprehensive solution for the following problem:

Problem: ${problem}

Context: ${context}

Existing Solutions Reference:
${existingSolutions?.map((s: any) => `- ${s.title}: ${s.description}`).join('\n') || 'No existing solutions available'}

Please generate a detailed solution with the following structure:
1. Solution Title
2. Problem Description
3. Root Causes
4. Step-by-Step Solution
5. Implementation Commands/Code
6. Verification Steps
7. Rollback Plan
8. Prevention Measures
9. Estimated Time to Fix
10. Success Rate

Format your response as JSON:
{
  "title": "string",
  "description": "string",
  "rootCauses": ["string"],
  "solutions": [
    {
      "title": "string",
      "description": "string",
      "command": "string",
      "code": "string",
      "verification": "string",
      "rollback": "string",
      "risk": "low|medium|high",
      "required": true
    }
  ],
  "prevention": [
    {
      "title": "string",
      "description": "string",
      "implementation": "string",
      "monitoring": "string"
    }
  ],
  "estimatedFixTime": number,
  "successRate": number,
  "tags": ["string"]
}`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt,
      stream: false,
      options: {
        temperature: 0.4,
        top_p: 0.9,
        num_predict: 800
      }
    }

    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(DEFAULT_OLLAMA_CONFIG.timeout),
    })

    if (!response.ok) {
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    
    try {
      const solution = JSON.parse(ollamaResponse.response)
      return NextResponse.json({
        success: true,
        solution,
        rawResponse: ollamaResponse.response
      })
    } catch (parseError) {
      return NextResponse.json({
        success: true,
        solution: {
          title: 'AI-Generated Solution',
          description: ollamaResponse.response,
          rootCauses: [],
          solutions: [],
          prevention: [],
          estimatedFixTime: 60,
          successRate: 75,
          tags: ['ai-generated']
        },
        rawResponse: ollamaResponse.response
      })
    }
  } catch (error) {
    console.error('Solution generation failed:', error)
    return NextResponse.json({
      success: false,
      error: `Failed to generate solution: ${error instanceof Error ? error.message : 'Unknown error'}`
    })
  }
}

async function improveKnowledgeBase(data: any) {
  try {
    const { failures, solutions, patterns } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    const prompt = `You are an expert in knowledge base management and Jenkins pipeline optimization. Analyze the following data and suggest improvements to the knowledge base:

Recent Failures:
${failures?.map((f: any) => `- ${f.reason}: ${f.count} occurrences`).join('\n') || 'No failure data available'}

Existing Solutions:
${solutions?.map((s: any) => `- ${s.title}: ${s.description} (Success rate: ${s.successRate}%)`).join('\n') || 'No solution data available'}

Failure Patterns:
${patterns?.map((p: any) => `- ${p.name}: ${p.description} (Frequency: ${p.frequency})`).join('\n') || 'No pattern data available'}

Please provide:
1. Gaps in current knowledge base
2. New solution templates needed
3. Pattern recognition insights
4. Categorization improvements
5. Automation opportunities

Format your response as JSON:
{
  "gaps": ["string"],
  "newSolutions": [
    {
      "title": "string",
      "description": "string",
      "category": "string",
      "severity": "low|medium|high|critical",
      "problemPatterns": ["string"],
      "estimatedFixTime": number,
      "successRate": number
    }
  ],
  "patterns": [
    {
      "name": "string",
      "description": "string",
      "category": "string",
      "frequency": number
    }
  ],
  "recommendations": ["string"],
  "automation": ["string"]
}`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt,
      stream: false,
      options: {
        temperature: 0.5,
        top_p: 0.9,
        num_predict: 600
      }
    }

    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(DEFAULT_OLLAMA_CONFIG.timeout),
    })

    if (!response.ok) {
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    
    try {
      const improvements = JSON.parse(ollamaResponse.response)
      return NextResponse.json({
        success: true,
        improvements,
        rawResponse: ollamaResponse.response
      })
    } catch (parseError) {
      return NextResponse.json({
        success: true,
        improvements: {
          gaps: [ollamaResponse.response],
          newSolutions: [],
          patterns: [],
          recommendations: [],
          automation: []
        },
        rawResponse: ollamaResponse.response
      })
    }
  } catch (error) {
    console.error('Knowledge base improvement failed:', error)
    return NextResponse.json({
      success: false,
      error: `Failed to improve knowledge base: ${error instanceof Error ? error.message : 'Unknown error'}`
    })
  }
}

async function chatWithOllama(data: any) {
  try {
    const { message, context, history } = data
    const baseUrl = data.config?.baseUrl || DEFAULT_OLLAMA_CONFIG.baseUrl
    const model = data.config?.model || DEFAULT_OLLAMA_CONFIG.model

    const systemPrompt = `You are an expert Jenkins pipeline assistant with deep knowledge of DevOps, CI/CD, and troubleshooting. You help users resolve pipeline issues, optimize builds, and implement best practices.

Context: ${context || 'Jenkins Pipeline Monitor'}

Previous conversation:
${history?.map((h: any) => `${h.role}: ${h.message}`).join('\n') || 'No previous conversation'}

User: ${message}

Please provide a helpful, accurate, and actionable response. If you need to suggest commands or code, format them clearly. If you're not sure about something, acknowledge the uncertainty and suggest ways to verify the information.`

    const ollamaRequest: OllamaRequest = {
      model,
      prompt: systemPrompt,
      stream: false,
      options: {
        temperature: 0.7,
        top_p: 0.9,
        num_predict: 400
      }
    }

    const response = await fetch(`${baseUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaRequest),
      signal: AbortSignal.timeout(DEFAULT_OLLAMA_CONFIG.timeout),
    })

    if (!response.ok) {
      throw new Error(`Ollama request failed: ${response.status} ${response.statusText}`)
    }

    const ollamaResponse: OllamaResponse = await response.json()
    
    return NextResponse.json({
      success: true,
      response: ollamaResponse.response,
      model: ollamaResponse.model,
      timestamp: ollamaResponse.created_at
    })
  } catch (error) {
    console.error('Chat failed:', error)
    return NextResponse.json({
      success: false,
      error: `Failed to chat: ${error instanceof Error ? error.message : 'Unknown error'}`
    })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get('action')

    if (action === 'models') {
      const baseUrl = searchParams.get('baseUrl') || DEFAULT_OLLAMA_CONFIG.baseUrl
      const response = await fetch(`${baseUrl}/api/tags`, {
        signal: AbortSignal.timeout(10000),
      })

      if (response.ok) {
        const data = await response.json()
        return NextResponse.json({
          success: true,
          models: data.models || []
        })
      } else {
        throw new Error(`Failed to fetch models: ${response.status} ${response.statusText}`)
      }
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Ollama GET request failed:', error)
    return NextResponse.json(
      { error: 'Failed to process Ollama request' },
      { status: 500 }
    )
  }
}