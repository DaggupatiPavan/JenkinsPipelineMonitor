import { NextRequest, NextResponse } from 'next/server'
import { jenkinsService } from '@/lib/jenkins'

export async function POST(request: NextRequest) {
  try {
    const { jobName, buildNumber, jenkinsUrl, username, apiToken } = await request.json()

    if (!jobName || !buildNumber) {
      return NextResponse.json(
        { error: 'Missing job name or build number' },
        { status: 400 }
      )
    }

    // Use environment variables if not provided
    const url = jenkinsUrl || process.env.NEXT_PUBLIC_JENKINS_URL
    const user = username || process.env.NEXT_PUBLIC_JENKINS_USERNAME
    const token = apiToken || process.env.NEXT_PUBLIC_JENKINS_API_TOKEN

    if (!url || !user || !token) {
      return NextResponse.json(
        { error: 'Missing Jenkins configuration' },
        { status: 400 }
      )
    }

    // Set configuration for this request
    jenkinsService.setConfig({
      url,
      username: user,
      apiToken: token
    })

    // Stop the build
    await jenkinsService.stopBuild(jobName, parseInt(buildNumber))

    return NextResponse.json({ 
      success: true, 
      message: `Build #${buildNumber} stopped for ${jobName}`,
      jobName,
      buildNumber
    })
  } catch (error) {
    console.error('Error stopping Jenkins build:', error)
    return NextResponse.json(
      { error: 'Failed to stop build' },
      { status: 500 }
    )
  }
}