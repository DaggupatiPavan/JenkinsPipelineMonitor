import { NextRequest, NextResponse } from 'next/server'
import { jenkinsService } from '@/lib/jenkins'

interface EnhancedLogRequest {
  jobName: string
  buildNumber?: number
  jenkinsUrl?: string
  username?: string
  apiToken?: string
  analysisType?: 'basic' | 'detailed' | 'ai-enhanced'
  includeMetrics?: boolean
  includePatterns?: boolean
}

interface LogAnalysis {
  summary: {
    totalLines: number
    errorCount: number
    warningCount: number
    infoCount: number
    debugCount: number
  }
  patterns: Array<{
    pattern: string
    matches: number
    severity: 'low' | 'medium' | 'high' | 'critical'
    examples: string[]
  }>
  timeline: Array<{
    timestamp: string
    level: string
    message: string
    stage?: string
  }>
  metrics?: {
    executionTime: number
    memoryUsage?: number
    throughput?: number
  }
  recommendations?: string[]
  aiInsights?: {
    rootCause?: string
    suggestedActions?: string[]
    confidence?: 'low' | 'medium' | 'high'
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as EnhancedLogRequest
    const {
      jobName,
      buildNumber,
      jenkinsUrl,
      username,
      apiToken,
      analysisType = 'basic',
      includeMetrics = false,
      includePatterns = false
    } = body

    if (!jobName) {
      return NextResponse.json(
        { error: 'Job name is required' },
        { status: 400 }
      )
    }

    // Set Jenkins configuration
    if (jenkinsUrl && username && apiToken) {
      jenkinsService.setConfig({
        url: jenkinsUrl,
        username,
        apiToken
      })
    }

    let actualBuildNumber = buildNumber
    
    // Get latest build number if not provided
    if (!actualBuildNumber) {
      try {
        const jobs = await jenkinsService.getJobs()
        const job = jobs.find(j => j.name === jobName)
        if (job && job.lastBuild) {
          actualBuildNumber = job.lastBuild.number
        }
      } catch (error) {
        console.warn('Failed to get latest build number:', error)
      }
    }

    if (!actualBuildNumber) {
      return NextResponse.json(
        { error: 'No build number found and none provided' },
        { status: 404 }
      )
    }

    // Fetch logs and build details
    const [logs, buildDetails] = await Promise.all([
      jenkinsService.getBuildLog(jobName, actualBuildNumber).catch(() => ''),
      jenkinsService.getBuildDetails(jobName, actualBuildNumber).catch(() => null)
    ])

    const logLines = logs.split('\n').filter(line => line.trim())
    
    // Perform log analysis
    const analysis: LogAnalysis = {
      summary: {
        totalLines: logLines.length,
        errorCount: 0,
        warningCount: 0,
        infoCount: 0,
        debugCount: 0
      },
      patterns: [],
      timeline: []
    }

    // Analyze log levels and patterns
    const errorPatterns = [
      /ERROR|FATAL|SEVERE/i,
      /Exception|Error/i,
      /Failed|Failure/i,
      /Timeout|timed out/i,
      /OutOfMemoryError|OOM/i
    ]

    const warningPatterns = [
      /WARN|WARNING/i,
      /Deprecated/i,
      /Slow operation/i,
      /Retry attempt/i
    ]

    const patternMatches: Record<string, { count: number; examples: string[] }> = {}

    logLines.forEach((line, index) => {
      // Count log levels
      if (errorPatterns.some(pattern => pattern.test(line))) {
        analysis.summary.errorCount++
      } else if (warningPatterns.some(pattern => pattern.test(line))) {
        analysis.summary.warningCount++
      } else if (/INFO/i.test(line)) {
        analysis.summary.infoCount++
      } else if (/DEBUG|TRACE/i.test(line)) {
        analysis.summary.debugCount++
      }

      // Extract patterns if requested
      if (includePatterns) {
        errorPatterns.forEach((pattern, patternIndex) => {
          const match = line.match(pattern)
          if (match) {
            const patternKey = `error_${patternIndex}`
            if (!patternMatches[patternKey]) {
              patternMatches[patternKey] = { count: 0, examples: [] }
            }
            patternMatches[patternKey].count++
            if (patternMatches[patternKey].examples.length < 3) {
              patternMatches[patternKey].examples.push(line.trim())
            }
          }
        })
      }

      // Build timeline (sample every 50 lines to avoid too much data)
      if (index % 50 === 0 || analysis.summary.errorCount > 0) {
        const timestamp = extractTimestamp(line)
        const level = extractLogLevel(line)
        const stage = extractStage(line)
        
        analysis.timeline.push({
          timestamp: timestamp || new Date().toISOString(),
          level: level || 'UNKNOWN',
          message: line.trim().substring(0, 200),
          stage
        })
      }
    })

    // Convert pattern matches to patterns array
    if (includePatterns) {
      Object.entries(patternMatches).forEach(([key, data]) => {
        const severity = data.count > 10 ? 'high' : data.count > 5 ? 'medium' : 'low'
        analysis.patterns.push({
          pattern: key.replace('error_', 'Error Pattern: '),
          matches: data.count,
          severity: severity as 'low' | 'medium' | 'high',
          examples: data.examples
        })
      })
    }

    // Add metrics if requested
    if (includeMetrics && buildDetails) {
      analysis.metrics = {
        executionTime: buildDetails.duration || 0,
        memoryUsage: extractMemoryUsage(logLines),
        throughput: calculateThroughput(logLines, buildDetails.duration)
      }
    }

    // Add AI-enhanced analysis if requested
    if (analysisType === 'ai-enhanced') {
      try {
        const aiResponse = await fetch(`${process.env.NEXT_PUBLIC_OLLAMA_BASE_URL || 'http://localhost:11434'}/api/generate`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: process.env.NEXT_PUBLIC_OLLAMA_MODEL || 'llama3.2',
            prompt: `Analyze these Jenkins build logs and provide insights:

Job: ${jobName}
Build: ${actualBuildNumber}
Error Count: ${analysis.summary.errorCount}
Warning Count: ${analysis.summary.warningCount}
Total Lines: ${analysis.summary.totalLines}

Sample Logs:
${logLines.slice(0, 20).join('\n')}

Provide:
1. Root cause analysis
2. Suggested actions
3. Confidence level (low/medium/high)

Format as JSON:
{
  "rootCause": "string",
  "suggestedActions": ["string"],
  "confidence": "low|medium|high"
}`,
            stream: false,
            options: {
              temperature: 0.3,
              num_predict: 300
            }
          })
        })

        if (aiResponse.ok) {
          const aiResult = await aiResponse.json()
          try {
            const aiInsights = JSON.parse(aiResult.response)
            analysis.aiInsights = {
              rootCause: aiInsights.rootCause,
              suggestedActions: aiInsights.suggestedActions,
              confidence: aiInsights.confidence
            }
          } catch (parseError) {
            // If JSON parsing fails, use raw response
            analysis.aiInsights = {
              rootCause: 'AI analysis completed but response format was unexpected',
              suggestedActions: [aiResult.response.substring(0, 200)],
              confidence: 'medium'
            }
          }
        }
      } catch (aiError) {
        console.warn('AI analysis failed, proceeding without AI insights:', aiError)
      }
    }

    // Generate basic recommendations
    analysis.recommendations = generateRecommendations(analysis)

    return NextResponse.json({
      success: true,
      jobName,
      buildNumber: actualBuildNumber,
      analysis,
      rawLogs: logs,
      buildDetails
    })

  } catch (error) {
    console.error('Enhanced log analysis failed:', error)
    return NextResponse.json(
      { error: `Failed to analyze logs: ${error instanceof Error ? error.message : 'Unknown error'}` },
      { status: 500 }
    )
  }
}

function extractTimestamp(line: string): string | null {
  // Try various timestamp formats
  const patterns = [
    /(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z?)/,
    /(\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2})/,
    /(\d{2}:\d{2}:\d{2})/,
    /(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})/
  ]

  for (const pattern of patterns) {
    const match = line.match(pattern)
    if (match) {
      return match[1]
    }
  }
  return null
}

function extractLogLevel(line: string): string | null {
  const levelMatch = line.match(/\b(ERROR|WARN|WARNING|INFO|DEBUG|TRACE|FATAL|SEVERE)\b/i)
  return levelMatch ? levelMatch[1].toUpperCase() : null
}

function extractStage(line: string): string | null {
  const stageMatch = line.match(/\[Pipeline\]\s*(\w+)/i) || line.match(/\[(.*?)\]/)
  return stageMatch ? stageMatch[1] : null
}

function extractMemoryUsage(logLines: string[]): number | undefined {
  const memoryPattern = /memory.*?(\d+(?:\.\d+)?)\s*(MB|GB)/i
  for (const line of logLines) {
    const match = line.match(memoryPattern)
    if (match) {
      const value = parseFloat(match[1])
      const unit = match[2].toUpperCase()
      return unit === 'GB' ? value * 1024 : value
    }
  }
  return undefined
}

function calculateThroughput(logLines: string[], durationMs: number): number | undefined {
  if (durationMs > 0) {
    return Math.round((logLines.length / durationMs) * 1000 * 100) / 100 // lines per second
  }
  return undefined
}

function generateRecommendations(analysis: LogAnalysis): string[] {
  const recommendations: string[] = []

  if (analysis.summary.errorCount > 0) {
    recommendations.push('Review error patterns and implement error handling')
  }

  if (analysis.summary.warningCount > analysis.summary.errorCount * 2) {
    recommendations.push('Address warning conditions to prevent future errors')
  }

  if (analysis.patterns.some(p => p.severity === 'high')) {
    recommendations.push('Immediate attention required for high-severity patterns')
  }

  if (analysis.metrics?.memoryUsage && analysis.metrics.memoryUsage > 2048) {
    recommendations.push('Consider optimizing memory usage or increasing allocation')
  }

  if (analysis.metrics?.executionTime && analysis.metrics.executionTime > 300000) {
    recommendations.push('Build time exceeds 5 minutes, consider optimization')
  }

  if (recommendations.length === 0) {
    recommendations.push('No critical issues detected, continue monitoring')
  }

  return recommendations
}